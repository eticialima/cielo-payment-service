# Django-Cielo

Biblioteca Django para integração com gateway de pagamento Cielo (Cartão de Crédito e PIX).

---

## 📦 Instalação

```bash
pip install django-cielo
```

---

## ⚙️ Configuração

### 1. Settings

```python
# settings.py
INSTALLED_APPS = [
    ...
    'rest_framework',
    'django_cielo',
]

DJANGO_CIELO = {
    'MERCHANT_ID': 'seu_merchant_id',
    'MERCHANT_KEY': 'sua_merchant_key',
    'SANDBOX': True,  # False para produção
}
```

### 2. Migrations

```bash
python manage.py migrate
```

---

## 🚀 Uso Básico

### Cartão de Crédito

```python
from django_cielo import CieloGateway

gateway = CieloGateway()
result = gateway.credit_card.create(
    card_number='4000000000001091',
    cardholder_name='TESTE',
    expiration_month='12',
    expiration_year='30',
    security_code='123',
    amount=10000,  # R$ 100,00 em centavos
    customer={'name': 'João', 'email': 'joao@test.com', 'cpf': '12345678900'}
)
```

### PIX

```python
result = gateway.pix.create(
    amount=10000,
    customer={'name': 'João', 'email': 'joao@test.com', 'cpf': '12345678900'},
    expiration_seconds=3600
)
qr_code = result['additional_data']['qr_code']
```

---

## 📖 Documentação Completa

- **[Cartão de Crédito](docs/cartao-credito.md)** - Parcelamento, validações, antifraude
- **[PIX](docs/pix.md)** - QR Code, webhooks, polling
- **[Customização](docs/customizacao.md)** - Como estender models e viewsets

---

## 📝 Exemplos

Veja a pasta [`examples/`](examples/) para exemplos completos:
- **exemplo_simple.py** - Setup básico
- **exemplo_completo.py** - Customização avançada
- **exemplo_parcelamento.py** - Sistema de parcelamento

---

## 🧪 Cartões de Teste (Sandbox)

| Bandeira | Número | Resultado |
|----------|--------|-----------|
| Visa | 4000000000001091 | ✅ Aprovado |
| Visa | 4000000000001000 | ❌ Negado |
| Master | 5200000000001096 | ✅ Aprovado |

---

## 📄 Licença

MIT License
    print(f"Pagamento negado: {result['denial_reason']}")
```

#### Opções Avançadas de Cartão

```python
result = gateway.credit_card.create(
    # Dados do cartão
    card_number='4000000000001091',
    cardholder_name='TESTE CIELO',
    expiration_month='12',
    expiration_year='30',
    security_code='123',
    
    # Valor e parcelamento
    amount=50000,  # R$ 500,00
    installments=3,  # 3x sem juros
    
    # Cliente
    customer={
        'name': 'João Silva',
        'email': 'joao@example.com',
        'cpf': '12345678900'
    },
    
    # Endereço de cobrança (opcional, mas recomendado para antifraude)
    billing_address={
        'street': 'Rua Exemplo',
        'number': '123',
        'complement': 'Apto 45',
        'district': 'Centro',
        'city': 'São Paulo',
        'state': 'SP',
        'zip_code': '01310-100'
    },
    
    # Configurações
    capture=True,  # Captura automática (padrão: True)
    authenticate=False,  # Habilitar 3DS (padrão: False)
    
    # Antifraude (opcional)
    session_id='abc123...',  # FingerPrintId do Cybersource
    client_ip='192.168.1.1',
    
    # ID customizado do pedido (opcional)
    merchant_order_id='PEDIDO-12345'
)
```

### 📱 Pagamento PIX

```python
result = gateway.pix.create(
    amount=10000,  # R$ 100,00
    customer={
        'name': 'João Silva',
        'email': 'joao@example.com',
        'cpf': '12345678900'
    },
    expiration_seconds=3600  # 1 hora (padrão: 3600, máximo: 86400)
)

if result['status'] == 'WAITING':
    qr_code = result['additional_data']['qr_code']
    qr_code_base64 = result['additional_data']['qr_code_base64']
    
    print(f"QR Code copia-e-cola: {qr_code}")
    print(f"Imagem QR Code (base64): {qr_code_base64[:50]}...")
    print(f"Payment ID: {result['payment_id']}")
```

### 🔍 Consultar Status de Pagamento

```python
# Consultar pelo PaymentId da Cielo
payment_info = gateway.query(payment_id='xxx-xxx-xxx-xxx')

payment_data = payment_info.get('Payment', {})
status = payment_data.get('Status')
return_message = payment_data.get('ReturnMessage')

print(f"Status: {status}")
print(f"Mensagem: {return_message}")
```

### 🔄 Cancelar/Estornar Pagamento

```python
# Cancelamento total
result = gateway.cancel(payment_id='xxx-xxx-xxx')

# Cancelamento parcial (R$ 50,00)
result = gateway.cancel(payment_id='xxx-xxx-xxx', amount=5000)
```

### 📥 Webhooks

Configure um endpoint para receber notificações da Cielo:

```python
# views.py
import json
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
from django_cielo import CieloGateway
from django_cielo.handlers import WebhookHandler

gateway = CieloGateway()
webhook_handler = WebhookHandler(gateway)

# Registrar callback para pagamentos aprovados
def on_payment_approved(payment_id, payment_data):
    print(f"Pagamento {payment_id} foi aprovado!")
    # Atualizar seu banco de dados
    # update_order_status(payment_id, 'paid')

webhook_handler.register_callback('approved', on_payment_approved)

@csrf_exempt
def cielo_webhook(request):
    """Endpoint para receber webhooks da Cielo"""
    try:
        data = json.loads(request.body)
        
        # Validar webhook
        if not webhook_handler.validate_webhook(data):
            return HttpResponse(status=400)
        
        # Processar webhook
        result = webhook_handler.process(data)
        
        if result['processed']:
            payment_id = result['payment_id']
            new_status = result['new_status']
            
            print(f"Webhook processado: {payment_id} -> {new_status}")
            
            # Atualizar seu sistema
            # update_payment_status(payment_id, new_status)
        
        return HttpResponse(status=200)
        
    except Exception as e:
        print(f"Erro ao processar webhook: {e}")
        return HttpResponse(status=500)
```

Configure a URL no `urls.py`:

```python
# urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('webhook/cielo/', views.cielo_webhook, name='cielo_webhook'),
]
```

## 🛡️ Validações

A biblioteca valida automaticamente os dados antes de enviar para a Cielo:

```python
from django_cielo.validators import CardValidator, CustomerValidator

# Validar cartão
is_valid, error = CardValidator.validate_card_number('4000000000001091')
if not is_valid:
    print(f"Erro: {error}")

# Validar cliente
customer_data = {
    'name': 'João Silva',
    'email': 'joao@example.com',
    'cpf': '12345678900'
}

try:
    CustomerValidator.validate_customer_data(customer_data)
    print("Dados válidos!")
except CieloValidationError as e:
    print(f"Erro de validação: {e.message}")
    print(f"Detalhes: {e.details}")
```

## 🎯 Handlers de Status

Use o `StatusHandler` para gerenciar status:

```python
from django_cielo.handlers import StatusHandler

# Converter status da Cielo (numérico) para interno
internal_status = StatusHandler.from_cielo(2)  # 'approved'

# Obter informações completas
status_info = StatusHandler.get_status_info(cielo_status=2, return_code='00')

print(status_info)
# {
#     'internal_status': 'approved',
#     'cielo_status': 2,
#     'display_text': 'Aprovado',
#     'is_final': True,
#     'is_success': True,
#     'can_retry': False,
#     'user_message': 'Pagamento aprovado com sucesso!'
# }

# Verificar se pode retentar
if StatusHandler.can_retry('denied'):
    print("Usuário pode tentar novamente")
```

## 🧪 Testes

### Modo Sandbox

Use o ambiente sandbox da Cielo para testes:

```python
DJANGO_CIELO = {
    'MERCHANT_ID': 'seu_merchant_id_sandbox',
    'MERCHANT_KEY': 'sua_merchant_key_sandbox',
    'SANDBOX': True,  # Usar sandbox
}
```

### Cartões de Teste (Sandbox)

| Bandeira | Número | Resultado |
|----------|--------|-----------|
| Visa | 4000000000001091 | Aprovado |
| Visa | 4000000000001000 | Negado |
| Master | 5200000000001096 | Aprovado |
| Master | 5200000000001005 | Negado |

### Mock Mode para PIX

Como o sandbox PIX ainda não está disponível, use o modo mock:

```python
DJANGO_CIELO = {
    'PIX_MOCK_MODE': True,  # Gera PIX simulado
}
```

## 🔧 Utilitários

```python
from django_cielo.utils import (
    mask_card_number,
    cents_to_currency,
    currency_to_cents,
    clean_card_number,
    generate_merchant_order_id
)

# Mascarar cartão para logs
masked = mask_card_number('4000000000001091')  # '400000******1091'

# Converter valores
reais = cents_to_currency(10000)  # 'R$ 100,00'
centavos = currency_to_cents(100.50)  # 10050

# Gerar ID único
order_id = generate_merchant_order_id('PEDIDO')  # 'PEDIDO-A1B2C3D4E5F6'
```

## 📊 Tratamento de Erros

```python
from django_cielo.exceptions import (
    CieloException,
    CieloValidationError,
    CieloAPIError,
    CieloPaymentDenied,
    CieloTimeoutError
)

try:
    result = gateway.credit_card.create(...)
    
except CieloValidationError as e:
    # Erro de validação (antes de enviar para Cielo)
    print(f"Dados inválidos: {e.message}")
    print(f"Detalhes: {e.details}")
    
except CieloPaymentDenied as e:
    # Pagamento negado pela operadora
    print(f"Pagamento negado: {e.return_message}")
    print(f"Código: {e.code}")
    
except CieloAPIError as e:
    # Erro retornado pela API
    print(f"Erro da API: {e.message}")
    print(f"Status Code: {e.status_code}")
    
except CieloTimeoutError as e:
    # Timeout na requisição
    print("Timeout - tente novamente")
    
except CieloException as e:
    # Qualquer outro erro da biblioteca
    print(f"Erro: {e.message}")
```

## 📚 Documentação da API Cielo

- [Manual Oficial Cielo](https://developercielo.github.io/manual/cielo-ecommerce)
- [API Reference](https://developercielo.github.io/manual/cielo-ecommerce#api-reference)
- [Códigos de Retorno](https://developercielo.github.io/manual/cielo-ecommerce#c%C3%B3digos-de-retorno-abecs)

## 🤝 Contribuindo

Contribuições são bem-vindas! Por favor:

1. Fork o repositório
2. Crie uma branch para sua feature (`git checkout -b feature/nova-feature`)
3. Commit suas mudanças (`git commit -am 'Adiciona nova feature'`)
4. Push para a branch (`git push origin feature/nova-feature`)
5. Abra um Pull Request

## 📝 Changelog

### v1.0.0 (2025-11-19)
- Release inicial
- Suporte a Cartão de Crédito
- Suporte a PIX (Cielo2)
- Sistema de webhooks
- Validações completas
- Handlers de status
- Modo mock para testes

## 📄 Licença

Este projeto está licenciado sob a licença MIT - veja o arquivo [LICENSE](LICENSE) para detalhes.

## 🆘 Suporte

- **Issues**: [GitHub Issues](https://github.com/DMC-Equipamentos/django-cielo/issues)
- **Email**: contato@dmcequipamentos.com.br

## ⚠️ Aviso

Esta biblioteca não é afiliada oficialmente à Cielo. Use por sua conta e risco.

---

Desenvolvido com ❤️ por [DMC Equipamentos](https://github.com/DMC-Equipamentos)
