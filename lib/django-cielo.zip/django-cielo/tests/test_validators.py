"""
Testes básicos para Django-Cielo
"""

import pytest
from django_cielo.validators import CardValidator, CustomerValidator, AmountValidator
from django_cielo.enums import CardBrand, PaymentStatus
from django_cielo.exceptions import CieloValidationError
from django_cielo.utils import (
    clean_card_number,
    mask_card_number,
    cents_to_currency,
    currency_to_cents,
    generate_merchant_order_id,
)


class TestCardValidator:
    """Testes para validador de cartão"""
    
    def test_validate_card_number_valid(self):
        is_valid, error = CardValidator.validate_card_number('4000000000001091')
        assert is_valid is True
        assert error == ''
    
    def test_validate_card_number_invalid_length(self):
        is_valid, error = CardValidator.validate_card_number('123')
        assert is_valid is False
        assert 'dígitos' in error.lower()
    
    def test_validate_card_number_empty(self):
        is_valid, error = CardValidator.validate_card_number('')
        assert is_valid is False
        assert 'obrigatório' in error.lower()
    
    def test_validate_cardholder_name_valid(self):
        is_valid, error = CardValidator.validate_cardholder_name('João Silva')
        assert is_valid is True
    
    def test_validate_cardholder_name_too_short(self):
        is_valid, error = CardValidator.validate_cardholder_name('Jo')
        assert is_valid is False
    
    def test_validate_cardholder_name_no_surname(self):
        is_valid, error = CardValidator.validate_cardholder_name('João')
        assert is_valid is False
    
    def test_validate_expiration_valid(self):
        is_valid, error = CardValidator.validate_expiration('12', '30')
        assert is_valid is True
    
    def test_validate_expiration_expired(self):
        is_valid, error = CardValidator.validate_expiration('01', '20')
        assert is_valid is False
        assert 'expirado' in error.lower()
    
    def test_validate_security_code_valid(self):
        is_valid, error = CardValidator.validate_security_code('123')
        assert is_valid is True
    
    def test_validate_security_code_invalid(self):
        is_valid, error = CardValidator.validate_security_code('12')
        assert is_valid is False
    
    def test_validate_card_data_all_valid(self):
        card_data = {
            'card_number': '4000000000001091',
            'cardholder_name': 'TESTE CIELO',
            'expiration_month': '12',
            'expiration_year': '30',
            'security_code': '123'
        }
        
        # Não deve lançar exceção
        CardValidator.validate_card_data(card_data)
    
    def test_validate_card_data_invalid_raises_exception(self):
        card_data = {
            'card_number': '123',  # Inválido
            'cardholder_name': 'T',  # Muito curto
            'expiration_month': '12',
            'expiration_year': '30',
            'security_code': '123'
        }
        
        with pytest.raises(CieloValidationError):
            CardValidator.validate_card_data(card_data)


class TestCustomerValidator:
    """Testes para validador de cliente"""
    
    def test_validate_email_valid(self):
        is_valid, error = CustomerValidator.validate_email('teste@example.com')
        assert is_valid is True
    
    def test_validate_email_invalid(self):
        is_valid, error = CustomerValidator.validate_email('email_invalido')
        assert is_valid is False
    
    def test_validate_email_empty(self):
        is_valid, error = CustomerValidator.validate_email('')
        assert is_valid is False
    
    def test_validate_cpf_valid_length(self):
        is_valid, error = CustomerValidator.validate_cpf('12345678900')
        assert is_valid is True
    
    def test_validate_cpf_invalid_length(self):
        is_valid, error = CustomerValidator.validate_cpf('123')
        assert is_valid is False
    
    def test_validate_customer_data_valid(self):
        customer_data = {
            'name': 'João Silva',
            'email': 'joao@example.com',
            'cpf': '12345678900'
        }
        
        CustomerValidator.validate_customer_data(customer_data)
    
    def test_validate_customer_data_invalid_raises_exception(self):
        customer_data = {
            'name': '',  # Vazio
            'email': 'email_invalido',
            'cpf': '123'  # Inválido
        }
        
        with pytest.raises(CieloValidationError):
            CustomerValidator.validate_customer_data(customer_data)


class TestAmountValidator:
    """Testes para validador de valor"""
    
    def test_validate_amount_valid(self):
        AmountValidator.validate_amount(10000)  # Não deve lançar exceção
    
    def test_validate_amount_zero_raises_exception(self):
        with pytest.raises(CieloValidationError):
            AmountValidator.validate_amount(0)
    
    def test_validate_amount_negative_raises_exception(self):
        with pytest.raises(CieloValidationError):
            AmountValidator.validate_amount(-100)
    
    def test_validate_amount_not_integer_raises_exception(self):
        with pytest.raises(CieloValidationError):
            AmountValidator.validate_amount(100.50)


class TestCardBrand:
    """Testes para detecção de bandeira"""
    
    def test_detect_visa(self):
        brand = CardBrand.detect('4000000000001091')
        assert brand == 'Visa'
    
    def test_detect_mastercard(self):
        brand = CardBrand.detect('5200000000001096')
        assert brand == 'Master'
    
    def test_detect_amex(self):
        brand = CardBrand.detect('340000000000009')
        assert brand == 'Amex'
    
    def test_detect_elo(self):
        brand = CardBrand.detect('6368000000000005')
        assert brand == 'Elo'


class TestPaymentStatus:
    """Testes para mapeamento de status"""
    
    def test_to_internal_authorized(self):
        status = PaymentStatus.to_internal(1)
        assert status == 'approved'
    
    def test_to_internal_payment_confirmed(self):
        status = PaymentStatus.to_internal(2)
        assert status == 'approved'
    
    def test_to_internal_denied(self):
        status = PaymentStatus.to_internal(3)
        assert status == 'denied'
    
    def test_to_internal_voided(self):
        status = PaymentStatus.to_internal(10)
        assert status == 'canceled'
    
    def test_to_internal_refunded(self):
        status = PaymentStatus.to_internal(11)
        assert status == 'refunded'
    
    def test_to_internal_pending(self):
        status = PaymentStatus.to_internal(12)
        assert status == 'pending'


class TestUtils:
    """Testes para utilitários"""
    
    def test_clean_card_number(self):
        cleaned = clean_card_number('4000 0000 0000 1091')
        assert cleaned == '4000000000001091'
    
    def test_clean_card_number_with_dashes(self):
        cleaned = clean_card_number('4000-0000-0000-1091')
        assert cleaned == '4000000000001091'
    
    def test_mask_card_number(self):
        masked = mask_card_number('4000000000001091')
        assert masked == '400000******1091'
    
    def test_mask_card_number_short(self):
        masked = mask_card_number('123')
        assert masked == '****'
    
    def test_cents_to_currency(self):
        formatted = cents_to_currency(10000)
        assert formatted == 'R$ 100,00'
    
    def test_cents_to_currency_with_cents(self):
        formatted = cents_to_currency(10050)
        assert formatted == 'R$ 100,50'
    
    def test_currency_to_cents(self):
        cents = currency_to_cents(100.00)
        assert cents == 10000
    
    def test_currency_to_cents_with_cents(self):
        cents = currency_to_cents(100.50)
        assert cents == 10050
    
    def test_generate_merchant_order_id(self):
        order_id = generate_merchant_order_id('PEDIDO')
        assert order_id.startswith('PEDIDO-')
        assert len(order_id) > 10
    
    def test_generate_merchant_order_id_unique(self):
        id1 = generate_merchant_order_id()
        id2 = generate_merchant_order_id()
        assert id1 != id2


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
