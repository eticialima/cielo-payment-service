"""
Configuração de testes para pytest
"""

import os
import django
from django.conf import settings

# Configurar Django para testes
if not settings.configured:
    settings.configure(
        DEBUG=True,
        DATABASES={
            'default': {
                'ENGINE': 'django.db.backends.sqlite3',
                'NAME': ':memory:',
            }
        },
        INSTALLED_APPS=[
            'django.contrib.contenttypes',
            'django.contrib.auth',
        ],
        SECRET_KEY='test-secret-key',
        USE_TZ=True,
        
        # Configurações Django-Cielo para testes
        DJANGO_CIELO={
            'MERCHANT_ID': 'test_merchant_id',
            'MERCHANT_KEY': 'test_merchant_key',
            'SANDBOX': True,
            'PIX_MOCK_MODE': True,
            'DEBUG': False,
        }
    )
    
    django.setup()
