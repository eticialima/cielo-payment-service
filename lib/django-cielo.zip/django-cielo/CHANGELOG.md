# Changelog

Todas as mudanças notáveis neste projeto serão documentadas neste arquivo.

## [1.0.0] - 2025-11-19

### Adicionado
- Release inicial da biblioteca Django-Cielo
- Suporte completo para pagamentos com Cartão de Crédito
- Suporte para pagamentos PIX (Cielo2)
- Sistema de validação de dados (cartão, cliente, valores)
- Handler de webhooks da Cielo
- Gerenciador de status de pagamentos
- Modo sandbox para testes
- Modo mock para PIX (sandbox PIX ainda não disponível)
- Detecção automática de bandeiras de cartão
- Utilitários para formatação e mascaramento de dados
- Sistema de logs configurável
- Suporte a múltiplos ambientes (sandbox/produção)
- Configuração via settings.py ou variáveis de ambiente
- Tratamento robusto de exceções
- Documentação completa com exemplos
- Testes unitários básicos
- Exemplos práticos de integração

### Características
- ✅ Cartão de Crédito com captura automática ou manual
- ✅ Parcelamento (até 12x)
- ✅ Antifraude Cybersource (opcional)
- ✅ PIX com QR Code
- ✅ Consulta de status de pagamento
- ✅ Cancelamento/estorno
- ✅ Webhooks para notificações
- ✅ Validações de Luhn para cartões
- ✅ Validações de CPF/CNPJ
- ✅ Type hints (Python 3.8+)
- ✅ Compatível com Django 3.2+

### Segurança
- Mascaramento automático de dados sensíveis em logs
- Validação de dados antes do envio
- Suporte a HTTPS obrigatório
- Timeout configurável para requisições

## [Unreleased]

### Planejado
- [ ] Suporte a cartão de débito
- [ ] Suporte a boleto bancário
- [ ] Autenticação 3DS (3D Secure)
- [ ] Recorrência (pagamentos recorrentes)
- [ ] Tokenização de cartões
- [ ] Retry automático em caso de timeout
- [ ] Cache de consultas de status
- [ ] Mais testes (cobertura > 90%)
- [ ] Documentação em inglês
- [ ] Integração com Django Rest Framework (serializers prontos)
- [ ] Webhook signature validation
