"""
Exemplo prático: Sistema completo de parcelamento
"""

from django_cielo import CieloGateway
from django_cielo.exceptions import CieloValidationError


class SistemaParcelamento:
    """Sistema de parcelamento para integração com Django-Cielo"""
    
    def __init__(self, min_valor_parcela=500, max_parcelas=12):
        """
        Args:
            min_valor_parcela: Valor mínimo da parcela em centavos (padrão: R$ 5,00)
            max_parcelas: Número máximo de parcelas (padrão: 12)
        """
        self.min_valor_parcela = min_valor_parcela
        self.max_parcelas = max_parcelas
        self.gateway = CieloGateway()
    
    def calcular_max_parcelas(self, valor_total):
        """
        Calcula o número máximo de parcelas permitidas
        
        Args:
            valor_total: Valor em centavos
            
        Returns:
            int: Número máximo de parcelas
        """
        if valor_total < self.min_valor_parcela:
            return 1
        
        max_possivel = valor_total // self.min_valor_parcela
        return min(max_possivel, self.max_parcelas)
    
    def gerar_opcoes_parcelamento(self, valor_total):
        """
        Gera todas as opções de parcelamento disponíveis
        
        Args:
            valor_total: Valor em centavos
            
        Returns:
            list: Lista de opções de parcelamento
        """
        max_parcelas = self.calcular_max_parcelas(valor_total)
        opcoes = []
        
        for n in range(1, max_parcelas + 1):
            valor_parcela = valor_total / n
            
            # Arredondar para evitar problemas com centavos
            valor_parcela_arredondado = round(valor_parcela)
            
            opcoes.append({
                'parcelas': n,
                'valor_parcela': valor_parcela_arredondado,
                'valor_total': valor_total,
                'juros': 0,
                'tipo': 'sem_juros',
                'descricao': self._formatar_descricao(n, valor_parcela_arredondado, valor_total)
            })
        
        return opcoes
    
    def _formatar_descricao(self, parcelas, valor_parcela, valor_total):
        """Formata descrição da opção de parcelamento"""
        if parcelas == 1:
            return f"À vista - R$ {valor_total/100:.2f}"
        else:
            return f"{parcelas}x de R$ {valor_parcela/100:.2f} sem juros"
    
    def validar_parcelamento(self, valor_total, parcelas):
        """
        Valida se o parcelamento é permitido
        
        Args:
            valor_total: Valor em centavos
            parcelas: Número de parcelas solicitado
            
        Returns:
            tuple: (is_valid, error_message)
        """
        # Verificar se parcelas está dentro do limite
        if parcelas < 1:
            return False, "Número de parcelas deve ser no mínimo 1"
        
        if parcelas > self.max_parcelas:
            return False, f"Número máximo de parcelas é {self.max_parcelas}"
        
        # Verificar valor mínimo da parcela
        valor_parcela = valor_total / parcelas
        if valor_parcela < self.min_valor_parcela:
            return False, (
                f"Valor da parcela (R$ {valor_parcela/100:.2f}) "
                f"é menor que o mínimo permitido (R$ {self.min_valor_parcela/100:.2f})"
            )
        
        return True, ""
    
    def processar_pagamento_parcelado(
        self,
        card_data,
        valor_total,
        parcelas,
        customer,
        billing_address=None
    ):
        """
        Processa pagamento parcelado
        
        Args:
            card_data: Dados do cartão
            valor_total: Valor em centavos
            parcelas: Número de parcelas
            customer: Dados do cliente
            billing_address: Endereço de cobrança (opcional)
            
        Returns:
            dict: Resultado do pagamento
        """
        # Validar parcelamento
        is_valid, error = self.validar_parcelamento(valor_total, parcelas)
        if not is_valid:
            return {
                'success': False,
                'error': error,
                'status': 'VALIDATION_ERROR'
            }
        
        try:
            # Processar pagamento
            result = self.gateway.credit_card.create(
                card_number=card_data['card_number'],
                cardholder_name=card_data['cardholder_name'],
                expiration_month=card_data['expiration_month'],
                expiration_year=card_data['expiration_year'],
                security_code=card_data['security_code'],
                amount=valor_total,
                installments=parcelas,
                customer=customer,
                billing_address=billing_address,
                capture=True
            )
            
            return {
                'success': result['status'] == 'APPROVED',
                'status': result['status'],
                'payment_id': result['payment_id'],
                'parcelas': parcelas,
                'valor_parcela': valor_total / parcelas,
                'valor_total': valor_total,
                'return_message': result.get('return_message', ''),
                'denial_reason': result.get('denial_reason', '')
            }
            
        except CieloValidationError as e:
            return {
                'success': False,
                'error': e.message,
                'status': 'VALIDATION_ERROR'
            }
        
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'status': 'ERROR'
            }


# ============================================================================
# EXEMPLO DE USO NO FEIRABACKEND
# ============================================================================

def exemplo_uso_sistema_parcelamento():
    """Exemplo completo de uso"""
    
    # Inicializar sistema
    sistema = SistemaParcelamento(
        min_valor_parcela=500,  # R$ 5,00
        max_parcelas=12
    )
    
    # Valor da compra
    valor_compra = 30000  # R$ 300,00
    
    # 1. GERAR OPÇÕES PARA MOSTRAR AO CLIENTE
    print("="*60)
    print("OPÇÕES DE PARCELAMENTO DISPONÍVEIS")
    print("="*60)
    
    opcoes = sistema.gerar_opcoes_parcelamento(valor_compra)
    
    for opcao in opcoes:
        print(opcao['descricao'])
    
    print("="*60)
    
    # 2. CLIENTE ESCOLHE 3 PARCELAS
    parcelas_escolhidas = 3
    
    # 3. VALIDAR ESCOLHA
    is_valid, error = sistema.validar_parcelamento(valor_compra, parcelas_escolhidas)
    
    if not is_valid:
        print(f"Erro: {error}")
        return
    
    print(f"\nCliente escolheu: {parcelas_escolhidas}x")
    print(f"Valor da parcela: R$ {(valor_compra/parcelas_escolhidas)/100:.2f}")
    
    # 4. PROCESSAR PAGAMENTO
    card_data = {
        'card_number': '4000000000001091',
        'cardholder_name': 'TESTE CIELO',
        'expiration_month': '12',
        'expiration_year': '30',
        'security_code': '123'
    }
    
    customer = {
        'name': 'João Silva',
        'email': 'joao@example.com',
        'cpf': '12345678900'
    }
    
    print("\nProcessando pagamento...")
    
    result = sistema.processar_pagamento_parcelado(
        card_data=card_data,
        valor_total=valor_compra,
        parcelas=parcelas_escolhidas,
        customer=customer
    )
    
    # 5. EXIBIR RESULTADO
    print("\n" + "="*60)
    print("RESULTADO DO PAGAMENTO")
    print("="*60)
    
    if result['success']:
        print(f"✅ Pagamento APROVADO!")
        print(f"Payment ID: {result['payment_id']}")
        print(f"Parcelas: {result['parcelas']}x de R$ {result['valor_parcela']/100:.2f}")
        print(f"Total: R$ {result['valor_total']/100:.2f}")
    else:
        print(f"❌ Pagamento NEGADO")
        print(f"Erro: {result.get('error', 'Desconhecido')}")
    
    print("="*60)


# ============================================================================
# INTEGRAÇÃO COM VIEW DO DJANGO
# ============================================================================

def view_processar_pagamento_parcelado(request):
    """
    View para processar pagamento parcelado
    
    POST /api/payments/card-installments/
    {
        "card_data": {...},
        "valor_total": 30000,
        "parcelas": 3,
        "customer": {...},
        "billing_address": {...}
    }
    """
    import json
    from django.http import JsonResponse
    
    try:
        data = json.loads(request.body)
        
        # Inicializar sistema
        sistema = SistemaParcelamento()
        
        # Validar parcelamento
        is_valid, error = sistema.validar_parcelamento(
            valor_total=data['valor_total'],
            parcelas=data['parcelas']
        )
        
        if not is_valid:
            return JsonResponse({
                'success': False,
                'error': error
            }, status=400)
        
        # Processar pagamento
        result = sistema.processar_pagamento_parcelado(
            card_data=data['card_data'],
            valor_total=data['valor_total'],
            parcelas=data['parcelas'],
            customer=data['customer'],
            billing_address=data.get('billing_address')
        )
        
        # Salvar no banco de dados aqui
        # payment = Payment.objects.create(...)
        
        return JsonResponse(result)
        
    except Exception as e:
        return JsonResponse({
            'success': False,
            'error': str(e)
        }, status=500)


def view_obter_opcoes_parcelamento(request, valor):
    """
    View para obter opções de parcelamento
    
    GET /api/payments/installment-options/<valor>/
    """
    from django.http import JsonResponse
    
    try:
        valor_centavos = int(valor)
        
        sistema = SistemaParcelamento()
        opcoes = sistema.gerar_opcoes_parcelamento(valor_centavos)
        
        return JsonResponse({
            'success': True,
            'valor_total': valor_centavos,
            'opcoes': opcoes
        })
        
    except Exception as e:
        return JsonResponse({
            'success': False,
            'error': str(e)
        }, status=500)


# ============================================================================
# EXEMPLO DE RESPOSTA PARA O FRONTEND
# ============================================================================

def exemplo_response_frontend():
    """
    Exemplo de JSON que o frontend receberia
    """
    return {
        "success": True,
        "valor_total": 30000,
        "opcoes": [
            {
                "parcelas": 1,
                "valor_parcela": 30000,
                "valor_total": 30000,
                "juros": 0,
                "tipo": "sem_juros",
                "descricao": "À vista - R$ 300,00"
            },
            {
                "parcelas": 2,
                "valor_parcela": 15000,
                "valor_total": 30000,
                "juros": 0,
                "tipo": "sem_juros",
                "descricao": "2x de R$ 150,00 sem juros"
            },
            {
                "parcelas": 3,
                "valor_parcela": 10000,
                "valor_total": 30000,
                "juros": 0,
                "tipo": "sem_juros",
                "descricao": "3x de R$ 100,00 sem juros"
            },
            # ... até max_parcelas
        ]
    }


if __name__ == '__main__':
    exemplo_uso_sistema_parcelamento()
