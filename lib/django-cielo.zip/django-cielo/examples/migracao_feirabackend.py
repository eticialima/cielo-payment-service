"""
EXEMPLO: Como migrar o código atual do FeiraBackend para usar Django-Cielo

Este arquivo mostra como refatorar o código existente em:
    FeiraBackend/VendasFeiraServer/payment/

Para usar a biblioteca Django-Cielo ao invés da implementação atual.
"""

# ============================================================================
# ANTES (Código Atual)
# ============================================================================

# from payment.payment_cielo import CieloPaymentGateway
# 
# gateway = CieloPaymentGateway()
# payment_response = gateway.create_credit_payment(
#     card_data=card_data,
#     transaction=transaction,
#     client_ip=client_ip,
#     session_id=session_id
# )


# ============================================================================
# DEPOIS (Usando Django-Cielo)
# ============================================================================

from django_cielo import CieloGateway
from django_cielo.exceptions import (
    CieloValidationError,
    CieloPaymentDenied,
    CieloAPIError
)

# Inicializar gateway (pode fazer no apps.py ou settings)
gateway = CieloGateway()


def processar_pagamento_cartao_refatorado(card_data, transaction, client_ip=None, session_id=None):
    """
    Versão refatorada usando Django-Cielo
    
    Esta função substitui:
        payment_gateway.create_credit_payment(...)
    """
    pedido = transaction.checkout_link.pedido
    comprador = pedido.comprador
    endereco_fatura = pedido.endereco_fatura
    
    try:
        # Preparar dados do cliente
        customer = {
            'name': comprador.name,
            'email': comprador.email,
            'cpf': comprador.cpf if comprador.cpf else '00000000000'
        }
        
        # Preparar endereço de cobrança (se existir)
        billing_address = None
        if endereco_fatura:
            billing_address = {
                'street': endereco_fatura.endereco or 'Rua Nao Informada',
                'number': endereco_fatura.numero or 'S/N',
                'complement': endereco_fatura.complemento or '',
                'district': endereco_fatura.bairro or 'Centro',
                'city': endereco_fatura.cidade or 'Cidade',
                'state': endereco_fatura.estado or 'SP',
                'zip_code': endereco_fatura.cep.replace('-', '') if endereco_fatura.cep else '00000000'
            }
        
        # Processar pagamento
        result = gateway.credit_card.create(
            # Dados do cartão
            card_number=card_data.get('card_number'),
            cardholder_name=card_data.get('cardholder_name'),
            expiration_month=card_data.get('expiration_month'),
            expiration_year=card_data.get('expiration_year'),
            security_code=card_data.get('security_code'),
            
            # Valor
            amount=transaction.valor,
            installments=1,
            
            # Cliente
            customer=customer,
            
            # Endereço
            billing_address=billing_address,
            
            # Antifraude (se fornecido)
            session_id=session_id,
            client_ip=client_ip,
            
            # Configurações
            capture=True,
            authenticate=False,
            
            # ID customizado
            merchant_order_id=f"DMC-{pedido.id}"
        )
        
        # Atualizar transação
        transaction.status = result['status'].lower()
        transaction.transaction_id = result['payment_id']
        transaction.payment_response = result['raw_response']
        
        if result['status'] == 'DENIED':
            transaction.error_message = result['denial_reason']
        
        transaction.save()
        
        # Marcar link como usado se aprovado
        if result['status'] == 'APPROVED':
            checkout_link = transaction.checkout_link
            checkout_link.usado = True
            checkout_link.save()
            
            # Atualizar pedido
            pedido.phase = "pago"
            pedido.save()
        
        return result
        
    except CieloValidationError as e:
        # Erro de validação (antes de enviar para Cielo)
        transaction.status = "denied"
        transaction.error_message = e.message
        transaction.save()
        
        return {
            "status": "DENIED",
            "error": e.message,
            "error_code": "VALIDATION_ERROR",
            "details": e.details
        }
    
    except CieloPaymentDenied as e:
        # Pagamento negado pela operadora
        transaction.status = "denied"
        transaction.error_message = e.return_message
        transaction.save()
        
        return {
            "status": "DENIED",
            "error": e.return_message,
            "return_code": e.code
        }
    
    except CieloAPIError as e:
        # Erro da API Cielo
        transaction.status = "denied"
        transaction.error_message = str(e)
        transaction.save()
        
        return {
            "status": "DENIED",
            "error": str(e),
            "error_code": e.code
        }
    
    except Exception as e:
        # Erro inesperado
        transaction.status = "denied"
        transaction.error_message = str(e)
        transaction.save()
        
        return {
            "status": "DENIED",
            "error": "Erro inesperado ao processar pagamento",
            "details": str(e)
        }


def processar_pagamento_pix_refatorado(transaction, qr_expiration_time=3600):
    """
    Versão refatorada do pagamento PIX usando Django-Cielo
    
    Esta função substitui:
        payment_gateway.create_pix_payment(...)
    """
    pedido = transaction.checkout_link.pedido
    comprador = pedido.comprador
    
    try:
        # Preparar dados do cliente
        customer = {
            'name': comprador.name,
            'email': comprador.email,
            'cpf': comprador.cpf if comprador.cpf else '00000000000'
        }
        
        # Processar PIX
        result = gateway.pix.create(
            amount=transaction.valor,
            customer=customer,
            expiration_seconds=qr_expiration_time,
            merchant_order_id=f"PIX-DMC-{pedido.id}"
        )
        
        # Atualizar transação
        transaction.status = 'waiting'
        transaction.transaction_id = result['payment_id']
        transaction.payment_response = result['raw_response']
        transaction.save()
        
        return result
        
    except Exception as e:
        transaction.status = "error"
        transaction.error_message = str(e)
        transaction.save()
        
        return {
            "status": "ERROR",
            "error": str(e)
        }


def consultar_status_refatorado(payment_id):
    """
    Consultar status de pagamento usando Django-Cielo
    
    Substitui: payment_gateway.query_payment(payment_id)
    """
    try:
        result = gateway.query(payment_id)
        return result
    except Exception as e:
        print(f"Erro ao consultar pagamento: {e}")
        return None


# ============================================================================
# CONFIGURAÇÃO DO WEBHOOK (usando Django-Cielo)
# ============================================================================

from django_cielo.handlers import WebhookHandler

# Inicializar handler
webhook_handler = WebhookHandler(gateway)


# Registrar callbacks
def on_payment_approved(payment_id, payment_data):
    """Callback quando pagamento for aprovado via webhook"""
    try:
        transaction = PaymentTransaction.objects.get(transaction_id=payment_id)
        transaction.status = 'approved'
        transaction.save()
        
        # Atualizar pedido
        pedido = transaction.checkout_link.pedido
        pedido.phase = "pago"
        pedido.save()
        
        # Marcar link como usado
        checkout_link = transaction.checkout_link
        checkout_link.usado = True
        checkout_link.save()
        
        print(f"Pagamento {payment_id} aprovado via webhook")
    except PaymentTransaction.DoesNotExist:
        print(f"Transação {payment_id} não encontrada")


webhook_handler.register_callback('approved', on_payment_approved)


def processar_webhook_cielo(request):
    """
    View para processar webhooks
    
    Pode substituir a view atual PaymentWebhookView
    """
    import json
    from django.http import HttpResponse
    from django.views.decorators.csrf import csrf_exempt
    
    try:
        data = json.loads(request.body)
        
        # Validar webhook
        if not webhook_handler.validate_webhook(data):
            return HttpResponse(status=400)
        
        # Processar
        result = webhook_handler.process(data)
        
        if result['processed']:
            # Registrar no banco (PaymentWebhook)
            webhook = PaymentWebhook.objects.create(
                transaction=PaymentTransaction.objects.filter(
                    transaction_id=result['payment_id']
                ).first(),
                event_type='cielo_payment_notification',
                payload=data,
                processed=True
            )
        
        return HttpResponse(status=200)
        
    except Exception as e:
        print(f"Erro ao processar webhook: {e}")
        return HttpResponse(status=500)


# ============================================================================
# VANTAGENS DA MIGRAÇÃO
# ============================================================================

"""
1. CÓDIGO MAIS LIMPO
   - Menos código boilerplate
   - API mais intuitiva
   - Melhor separação de responsabilidades

2. VALIDAÇÕES AUTOMÁTICAS
   - Validação de cartão (Luhn)
   - Validação de CPF/CNPJ
   - Validação de email
   - Validação de valores

3. TRATAMENTO DE ERROS ROBUSTO
   - Exceções específicas para cada tipo de erro
   - Mensagens de erro mais claras
   - Fácil identificar onde ocorreu o problema

4. REUTILIZÁVEL
   - Pode usar em outros projetos Django
   - Não precisa copiar/colar código
   - Atualizações centralizadas

5. TESTÁVEL
   - Testes unitários incluídos
   - Mock mode para PIX
   - Sandbox mode para cartão

6. DOCUMENTADO
   - README completo
   - Exemplos práticos
   - Type hints

7. MANUTENÍVEL
   - Código bem estruturado
   - Fácil adicionar novas features
   - Fácil fazer debug com logs
"""


# ============================================================================
# CONFIGURAÇÃO NO settings.py DO FEIRABACKEND
# ============================================================================

"""
# settings.py

DJANGO_CIELO = {
    # Credenciais da Cielo
    'MERCHANT_ID': os.getenv('CIELO_MERCHANT_ID', ''),
    'MERCHANT_KEY': os.getenv('CIELO_MERCHANT_KEY', ''),
    
    # Ambiente (sandbox ou produção)
    'SANDBOX': os.getenv('CIELO_SANDBOX', 'True').lower() == 'true',
    
    # PIX mock mode (enquanto sandbox não disponível)
    'PIX_MOCK_MODE': os.getenv('PIX_MOCK_MODE', 'False').lower() == 'true',
    
    # Timeout das requisições
    'TIMEOUT': 30,
    
    # Debug (habilita logs detalhados)
    'DEBUG': DEBUG,  # Usar mesmo DEBUG do Django
    
    # Soft descriptor (aparece na fatura do cliente)
    'SOFT_DESCRIPTOR': 'DMC*FEIRA',
}
"""
