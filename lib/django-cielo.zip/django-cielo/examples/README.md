# Exemplos Django-Cielo

Esta pasta contém exemplos práticos de uso da biblioteca django-cielo.

---

## 📂 Estrutura dos Exemplos

### 1️⃣ **exemplo_simple.py** - Começe aqui!

**Para quem:** Iniciantes, uso rápido

**O que mostra:**
- ✅ Configuração básica (settings.py + urls.py)
- ✅ Usar o Gateway diretamente
- ✅ Pagamento com cartão
- ✅ Pagamento PIX
- ✅ Parcelamento básico
- ✅ Uso via API REST (sem customização)

**Execute:**
```bash
python exemplo_simple.py
```

---

### 2️⃣ **exemplo_completo.py** - Customização Total

**Para quem:** Projetos reais, necessidade de customização

**O que mostra:**
- ✅ Models customizados (herdar de Base classes)
- ✅ Relacionamento com Order do seu sistema
- ✅ ViewSets personalizados
- ✅ Admin customizado com campos extras
- ✅ Autenticação e permissões
- ✅ Endpoints adicionais (analytics, stats)
- ✅ Análise de risco

**Arquivos gerados:**
- `payment/models.py` - Models customizados
- `payment/views.py` - ViewSets customizados
- `payment/admin.py` - Admin customizado
- `payment/urls.py` - URLs
- `payment/serializers.py` - Serializers

---

### 3️⃣ **exemplo_parcelamento.py** - Sistema de Parcelamento

**Para quem:** E-commerce, lojas que precisam parcelamento

**O que mostra:**
- ✅ Classe `SistemaParcelamento`
- ✅ Calcular número máximo de parcelas
- ✅ Gerar opções de parcelamento
- ✅ Validar parcelamento (valor mínimo da parcela)
- ✅ Processar pagamento parcelado
- ✅ Integração com views Django

**Execute:**
```bash
python exemplo_parcelamento.py
```

**Exemplo de resposta:**
```json
{
  "success": true,
  "opcoes": [
    {"parcelas": 1, "valor_parcela": 30000, "descricao": "À vista - R$ 300,00"},
    {"parcelas": 2, "valor_parcela": 15000, "descricao": "2x de R$ 150,00 sem juros"},
    {"parcelas": 3, "valor_parcela": 10000, "descricao": "3x de R$ 100,00 sem juros"}
  ]
}
```

---

### 4️⃣ **django_views.py** - Views Django (sem DRF)

**Para quem:** Projetos que não usam Django REST Framework

**O que mostra:**
- ✅ Views baseadas em função
- ✅ `@require_http_methods` decorators
- ✅ JsonResponse
- ✅ Integração com templates Django

---

## 🚀 Como Usar

### 1. Instale a biblioteca

```bash
pip install django-cielo
```

### 2. Configure settings.py

```python
DJANGO_CIELO = {
    'MERCHANT_ID': 'seu_merchant_id',
    'MERCHANT_KEY': 'sua_merchant_key',
    'SANDBOX': True,
}
```

### 3. Escolha o exemplo apropriado

| Situação | Exemplo |
|----------|---------|
| Começando do zero | `exemplo_simple.py` |
| Projeto com Order/Pedido | `exemplo_completo.py` |
| Precisa parcelamento | `exemplo_parcelamento.py` |
| Não usa Django REST Framework | `django_views.py` |

---

## 📚 Documentação Detalhada

Veja a pasta `docs/` para guias completos:

- **[Cartão de Crédito](../docs/cartao-credito.md)** - Guia completo
- **[PIX](../docs/pix.md)** - Guia completo
- **[Customização](../docs/customizacao.md)** - Como estender

---

## 🧪 Cartões de Teste (Sandbox)

| Final | Status | Código |
|-------|--------|--------|
| XXX**0** | ✅ Aprovado | 4/6 |
| XXX**1** | ✅ Aprovado | 4/6 |
| XXX**2** | ❌ Negado | 05 |
| XXX**3** | ❌ Expirado | 57 |
| XXX**5** | ❌ Bloqueado | 78 |
| XXX**7** | ❌ Cancelado | 77 |
| XXX**8** | ❌ Problemas | 70 |

**Exemplo:** `4000000000001091` = Aprovado ✅

---

## 💡 Dicas

1. **Sempre teste no Sandbox primeiro** (`SANDBOX=True`)
2. **Use os cartões de teste** para simular diferentes cenários
3. **Configure webhooks** para receber notificações de pagamento
4. **Monitore o Admin** (`/admin/`) para ver transações e tentativas

---

## ❓ Precisa de Ajuda?

- [README Principal](../README.md)
- [Documentação Completa](../docs/)
- [Issues no GitHub](https://github.com/DMC-Equipamentos/django-cielo/issues)
