"""
Exemplo Simples - Uso básico do Gateway
========================================

Este exemplo mostra o uso mais simples da biblioteca:
- Configurar settings
- Usar o Gateway diretamente
- Processar pagamentos com cartão e PIX
"""

# ============================================================================
# 1. CONFIGURAÇÃO (settings.py)
# ============================================================================

# settings.py
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'rest_framework',
    'django_cielo',  # ← Adicionar
]

DJANGO_CIELO = {
    'MERCHANT_ID': 'seu_merchant_id_aqui',
    'MERCHANT_KEY': 'sua_merchant_key_aqui',
    'SANDBOX': True,  # True para testes
}


# ============================================================================
# 2. URLS (urls.py)
# ============================================================================

# urls.py
from django.contrib import admin
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from django_cielo.viewsets import BasePaymentViewSet

# Router REST API
router = DefaultRouter()
router.register(r'payment', BasePaymentViewSet, basename='payment')

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/', include(router.urls)),
]


# ============================================================================
# 3. MIGRATIONS
# ============================================================================

# Terminal:
# python manage.py migrate


# ============================================================================
# 4. USO BÁSICO - Gateway Direto
# ============================================================================

from django_cielo import CieloGateway

# Inicializar gateway (usa configurações do settings.py)
gateway = CieloGateway()


# ---------- PAGAMENTO COM CARTÃO ----------

def exemplo_cartao():
    """Exemplo básico de pagamento com cartão"""
    
    result = gateway.credit_card.create(
        # Dados do cartão
        card_number='4000000000001091',  # Cartão de teste
        cardholder_name='TESTE CIELO',
        expiration_month='12',
        expiration_year='30',
        security_code='123',
        
        # Valor
        amount=10000,  # R$ 100,00 (em centavos)
        
        # Cliente
        customer={
            'name': 'João Silva',
            'email': 'joao@example.com',
            'cpf': '12345678900'
        }
    )
    
    # Verificar resultado
    if result['status'] == 'APPROVED':
        print(f"✅ Pagamento aprovado!")
        print(f"Payment ID: {result['payment_id']}")
    else:
        print(f"❌ Pagamento negado: {result.get('denial_reason')}")
    
    return result


# ---------- PAGAMENTO PIX ----------

def exemplo_pix():
    """Exemplo básico de pagamento PIX"""
    
    result = gateway.pix.create(
        # Valor
        amount=10000,  # R$ 100,00
        
        # Cliente
        customer={
            'name': 'João Silva',
            'email': 'joao@example.com',
            'cpf': '12345678900'
        },
        
        # Validade do QR Code
        expiration_seconds=3600  # 1 hora
    )
    
    # QR Code gerado
    print(f"QR Code: {result['additional_data']['qr_code']}")
    print(f"Status: {result['status']}")  # 'WAITING'
    
    return result


# ---------- PARCELAMENTO ----------

def exemplo_parcelamento():
    """Exemplo de pagamento parcelado"""
    
    result = gateway.credit_card.create(
        card_number='4000000000001091',
        cardholder_name='TESTE',
        expiration_month='12',
        expiration_year='30',
        security_code='123',
        amount=30000,  # R$ 300,00
        installments=3,  # 3x sem juros
        customer={
            'name': 'João Silva',
            'email': 'joao@example.com',
            'cpf': '12345678900'
        }
    )
    
    return result


# ============================================================================
# 5. USO VIA API REST
# ============================================================================

"""
Após configurar URLs, você tem acesso a:

1. Criar CheckoutLink:
   
   from django_cielo.models import CheckoutLink
   from datetime import timedelta
   from django.utils import timezone
   
   checkout = CheckoutLink.objects.create(
       amount=10000,
       expires_at=timezone.now() + timedelta(hours=24)
   )

2. Processar pagamento via API:
   
   POST /api/payment/process/
   {
     "chave": "checkout_key_aqui",
     "payment_method": "credit_card",
     "card_data": {
       "card_number": "4000000000001091",
       "cardholder_name": "TESTE",
       "expiration_month": "12",
       "expiration_year": "30",
       "security_code": "123"
     },
     "customer": {
       "name": "João Silva",
       "email": "joao@test.com",
       "cpf": "12345678900"
     }
   }

3. Ver no Admin:
   
   /admin/ → 01 - Checkout Links
   /admin/ → 02 - Transações de Pagamento
"""


# ============================================================================
# 6. TESTE RÁPIDO
# ============================================================================

if __name__ == '__main__':
    print("=" * 60)
    print("TESTE - PAGAMENTO COM CARTÃO")
    print("=" * 60)
    
    resultado = exemplo_cartao()
    print(f"\nStatus: {resultado['status']}")
    
    print("\n" + "=" * 60)
    print("TESTE - PAGAMENTO PIX")
    print("=" * 60)
    
    resultado_pix = exemplo_pix()
    print(f"\nStatus: {resultado_pix['status']}")
    print("QR Code gerado com sucesso!")
