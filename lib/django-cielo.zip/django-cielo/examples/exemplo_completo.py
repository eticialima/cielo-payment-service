"""
Exemplo Completo - Customização Total
======================================

Este exemplo mostra como estender a biblioteca completamente:
- Herdar de classes base
- Models customizados
- ViewSets personalizados
- Admin customizado
- Lógica de negócio adicional
"""

# ============================================================================
# 1. MODELS CUSTOMIZADOS (payment/models.py)
# ============================================================================

from django.db import models
from django.utils import timezone
from django_cielo.models import (
    BaseCheckoutLink,
    BasePaymentTransaction,
    BasePaymentAttempt,
    BasePaymentWebhook
)


class Order(models.Model):
    """Model de pedido (seu sistema)"""
    customer_name = models.CharField(max_length=200)
    customer_email = models.EmailField()
    total = models.DecimalField(max_digits=10, decimal_places=2)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        verbose_name = "Pedido"
        verbose_name_plural = "Pedidos"


class CheckoutLink(BaseCheckoutLink):
    """CheckoutLink customizado com relacionamento"""
    
    # Relacionamento com Order
    order = models.ForeignKey(
        Order,
        on_delete=models.CASCADE,
        related_name='checkouts'
    )
    
    # Campos customizados
    customer_ip = models.GenericIPAddressField(null=True, blank=True)
    referrer = models.CharField(max_length=500, blank=True)
    utm_source = models.CharField(max_length=100, blank=True)
    
    class Meta:
        verbose_name = "01 - Checkout Link"
        verbose_name_plural = "01 - Checkout Links"
        ordering = ['-created_at']
    
    def __str__(self):
        return f"Checkout #{self.order.id} - {self.key[:8]}..."


class PaymentTransaction(BasePaymentTransaction):
    """Transaction customizada"""
    
    # Relacionamento direto (ao invés de GenericForeignKey)
    checkout_link = models.ForeignKey(
        CheckoutLink,
        on_delete=models.PROTECT,
        related_name='transactions'
    )
    
    # Campos adicionais
    customer_ip = models.GenericIPAddressField(null=True, blank=True)
    user_agent = models.TextField(blank=True)
    risk_score = models.IntegerField(null=True, blank=True)
    fraud_analysis = models.JSONField(null=True, blank=True)
    
    class Meta:
        verbose_name = "02 - Transação"
        verbose_name_plural = "02 - Transações"
        ordering = ['-created_at']
    
    def __str__(self):
        return f"Transaction #{self.id} - {self.status} - Order #{self.checkout_link.order.id}"


class PaymentAttempt(BasePaymentAttempt):
    """Attempt customizado"""
    transaction = models.ForeignKey(
        PaymentTransaction,
        on_delete=models.CASCADE,
        related_name='attempts'
    )
    
    class Meta:
        verbose_name = "03 - Tentativa"
        verbose_name_plural = "03 - Tentativas"
        ordering = ['-attempted_at']


class PaymentWebhook(BasePaymentWebhook):
    """Webhook customizado"""
    transaction = models.ForeignKey(
        PaymentTransaction,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='webhooks'
    )
    
    class Meta:
        verbose_name = "04 - Webhook"
        verbose_name_plural = "04 - Webhooks"
        ordering = ['-received_at']


# ============================================================================
# 2. VIEWSETS CUSTOMIZADOS (payment/views.py)
# ============================================================================

from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django_cielo.viewsets import BasePaymentViewSet
from django.shortcuts import get_object_or_404
from .models import CheckoutLink, PaymentTransaction


class PaymentViewSet(BasePaymentViewSet):
    """ViewSet customizado com autenticação e lógica adicional"""
    
    # Autenticação
    permission_classes = [IsAuthenticated]
    
    def get_permissions(self):
        """Webhook e process são públicos"""
        if self.action in ['webhook', 'process']:
            return []
        return [IsAuthenticated()]
    
    def get_checkout_object(self, checkout_id):
        """Override para usar nosso model"""
        # Se for numérico, buscar por ID
        if str(checkout_id).isdigit():
            return get_object_or_404(
                CheckoutLink.objects.select_related('order'),
                id=checkout_id
            )
        # Se não, buscar por key
        return get_object_or_404(
            CheckoutLink.objects.select_related('order'),
            key=checkout_id
        )
    
    def create_transaction(self, checkout, payment_data):
        """Override para adicionar campos customizados"""
        return PaymentTransaction.objects.create(
            checkout_link=checkout,
            amount=checkout.amount,
            payment_method=payment_data.get('payment_method', 'credit_card'),
            gateway_provider='cielo',
            status='pending',
            # Campos customizados
            customer_ip=self.request.META.get('REMOTE_ADDR'),
            user_agent=self.request.META.get('HTTP_USER_AGENT', ''),
        )
    
    @action(detail=False, methods=['post'])
    def create_checkout(self, request):
        """Endpoint customizado para criar checkout com order"""
        order_id = request.data.get('order_id')
        order = get_object_or_404(Order, id=order_id)
        
        checkout = CheckoutLink.objects.create(
            order=order,
            amount=int(order.total * 100),  # Converter para centavos
            customer_ip=request.META.get('REMOTE_ADDR'),
        )
        
        return Response({
            'checkout_id': checkout.id,
            'checkout_key': checkout.key,
            'order_id': order.id,
            'amount': checkout.amount,
            'expires_at': checkout.expires_at,
        }, status=status.HTTP_201_CREATED)
    
    @action(detail=True, methods=['get'])
    def analytics(self, request, pk=None):
        """Endpoint para analytics da transação"""
        transaction = get_object_or_404(
            PaymentTransaction.objects.select_related('checkout_link__order'),
            id=pk
        )
        
        return Response({
            'transaction_id': transaction.id,
            'order_id': transaction.checkout_link.order.id,
            'amount': transaction.amount,
            'status': transaction.status,
            'payment_method': transaction.payment_method,
            'created_at': transaction.created_at,
            'payment_date': transaction.payment_date,
            'attempts_count': transaction.attempts.count(),
            'webhooks_count': transaction.webhooks.count(),
            'customer_ip': transaction.customer_ip,
        })
    
    @action(detail=False, methods=['get'])
    def stats(self, request):
        """Estatísticas gerais de pagamentos"""
        from django.db.models import Count, Sum, Q
        
        stats = PaymentTransaction.objects.aggregate(
            total_transactions=Count('id'),
            total_approved=Count('id', filter=Q(status='approved')),
            total_denied=Count('id', filter=Q(status='denied')),
            total_amount=Sum('amount', filter=Q(status='approved')),
        )
        
        return Response({
            'total_transactions': stats['total_transactions'],
            'total_approved': stats['total_approved'],
            'total_denied': stats['total_denied'],
            'total_amount': stats['total_amount'] or 0,
            'approval_rate': (
                stats['total_approved'] / stats['total_transactions'] * 100
                if stats['total_transactions'] > 0 else 0
            )
        })


# ============================================================================
# 3. ADMIN CUSTOMIZADO (payment/admin.py)
# ============================================================================

from django.contrib import admin
from django.utils.html import format_html
from django_cielo.admin import (
    CheckoutLinkAdmin as BaseCheckoutLinkAdmin,
    PaymentTransactionAdmin as BaseTransactionAdmin,
)
from .models import Order, CheckoutLink, PaymentTransaction


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ('id', 'customer_name', 'customer_email', 'total', 'created_at')
    search_fields = ('customer_name', 'customer_email')
    list_filter = ('created_at',)


@admin.register(CheckoutLink)
class CheckoutLinkAdmin(BaseCheckoutLinkAdmin):
    """Admin customizado com campos adicionais"""
    
    list_display = BaseCheckoutLinkAdmin.list_display + (
        'order', 'customer_ip', 'utm_source'
    )
    
    list_filter = BaseCheckoutLinkAdmin.list_filter + ('utm_source',)
    
    fieldsets = BaseCheckoutLinkAdmin.fieldsets + (
        ('Informações Adicionais', {
            'fields': ('order', 'customer_ip', 'referrer', 'utm_source')
        }),
    )
    
    def get_queryset(self, request):
        return super().get_queryset(request).select_related('order')


@admin.register(PaymentTransaction)
class PaymentTransactionAdmin(BaseTransactionAdmin):
    """Admin customizado com análise de risco"""
    
    list_display = BaseTransactionAdmin.list_display + (
        'get_order', 'customer_ip', 'get_risk_badge'
    )
    
    fieldsets = BaseTransactionAdmin.fieldsets + (
        ('Análise de Risco', {
            'fields': ('customer_ip', 'user_agent', 'risk_score', 'fraud_analysis'),
            'classes': ('collapse',)
        }),
    )
    
    def get_order(self, obj):
        return f"Order #{obj.checkout_link.order.id}"
    get_order.short_description = "Pedido"
    
    def get_risk_badge(self, obj):
        if not obj.risk_score:
            return '-'
        
        if obj.risk_score < 30:
            color = 'green'
            text = 'Baixo'
        elif obj.risk_score < 70:
            color = 'orange'
            text = 'Médio'
        else:
            color = 'red'
            text = 'Alto'
        
        return format_html(
            '<span style="background:{};color:white;padding:3px 8px;border-radius:3px;">{}</span>',
            color, text
        )
    get_risk_badge.short_description = "Risco"
    
    def get_queryset(self, request):
        return super().get_queryset(request).select_related('checkout_link__order')


# ============================================================================
# 4. URLS (payment/urls.py)
# ============================================================================

from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import PaymentViewSet

router = DefaultRouter()
router.register(r'payment', PaymentViewSet, basename='payment')

urlpatterns = [
    path('', include(router.urls)),
]

# No urls.py principal:
# path('api/', include('payment.urls'))


# ============================================================================
# 5. SERIALIZERS (payment/serializers.py)
# ============================================================================

from rest_framework import serializers
from .models import PaymentTransaction, Order


class OrderSerializer(serializers.ModelSerializer):
    class Meta:
        model = Order
        fields = ['id', 'customer_name', 'customer_email', 'total']


class TransactionSerializer(serializers.ModelSerializer):
    order = OrderSerializer(source='checkout_link.order', read_only=True)
    status_display = serializers.CharField(source='get_status_display', read_only=True)
    
    class Meta:
        model = PaymentTransaction
        fields = [
            'id', 'status', 'status_display', 'payment_method',
            'amount', 'transaction_id', 'created_at', 'payment_date',
            'order', 'customer_ip'
        ]


# ============================================================================
# 6. EXEMPLO DE USO
# ============================================================================

if __name__ == '__main__':
    """
    Endpoints disponíveis:
    
    POST   /api/payment/create_checkout/    - Criar checkout com order
    POST   /api/payment/process/            - Processar pagamento
    POST   /api/payment/webhook/            - Receber webhook
    GET    /api/payment/{id}/analytics/     - Analytics da transação
    GET    /api/payment/stats/              - Estatísticas gerais
    POST   /api/payment/{id}/cancel/        - Cancelar transação
    POST   /api/payment/{id}/refund/        - Reembolsar transação
    """
    
    print("=" * 60)
    print("EXEMPLO COMPLETO - CUSTOMIZAÇÃO TOTAL")
    print("=" * 60)
    print("\nModels customizados:")
    print("  ✓ Order")
    print("  ✓ CheckoutLink (+ order, customer_ip, referrer, utm_source)")
    print("  ✓ PaymentTransaction (+ customer_ip, user_agent, risk_score)")
    print("\nViewSets customizados:")
    print("  ✓ create_checkout/")
    print("  ✓ analytics/")
    print("  ✓ stats/")
    print("\nAdmin customizado:")
    print("  ✓ OrderAdmin")
    print("  ✓ CheckoutLinkAdmin (+ campos extras)")
    print("  ✓ PaymentTransactionAdmin (+ análise de risco)")
    print("=" * 60)
