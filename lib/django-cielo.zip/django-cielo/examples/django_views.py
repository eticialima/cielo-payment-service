"""
Exemplo de integração com Django Views
"""

import json
from django.http import JsonResponse, HttpResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
from django_cielo import CieloGateway
from django_cielo.handlers import WebhookHandler
from django_cielo.exceptions import CieloException


# Inicializar gateway (pode ser feito em apps.py)
gateway = CieloGateway()
webhook_handler = WebhookHandler(gateway)


@require_http_methods(["POST"])
def processar_pagamento_cartao(request):
    """
    Endpoint para processar pagamento com cartão
    
    POST /api/payments/card/
    {
        "card_number": "4000000000001091",
        "cardholder_name": "TESTE CIELO",
        "expiration_month": "12",
        "expiration_year": "30",
        "security_code": "123",
        "amount": 10000,
        "installments": 1,
        "customer": {
            "name": "João Silva",
            "email": "joao@example.com",
            "cpf": "12345678900"
        },
        "billing_address": {...}
    }
    """
    try:
        data = json.loads(request.body)
        
        # Extrair dados
        card_data = {
            'card_number': data['card_number'],
            'cardholder_name': data['cardholder_name'],
            'expiration_month': data['expiration_month'],
            'expiration_year': data['expiration_year'],
            'security_code': data['security_code'],
        }
        
        amount = data['amount']
        installments = data.get('installments', 1)
        customer = data['customer']
        billing_address = data.get('billing_address')
        
        # Processar pagamento
        result = gateway.credit_card.create(
            **card_data,
            amount=amount,
            installments=installments,
            customer=customer,
            billing_address=billing_address
        )
        
        # Salvar no banco de dados
        # payment = Payment.objects.create(
        #     payment_id=result['payment_id'],
        #     status=result['status'],
        #     amount=amount,
        #     ...
        # )
        
        return JsonResponse({
            'success': True,
            'payment_id': result['payment_id'],
            'status': result['status'],
            'message': 'Pagamento processado com sucesso' if result['status'] == 'APPROVED' else result.get('denial_reason', '')
        })
        
    except CieloException as e:
        return JsonResponse({
            'success': False,
            'error': str(e),
            'code': e.code
        }, status=400)
    
    except Exception as e:
        return JsonResponse({
            'success': False,
            'error': str(e)
        }, status=500)


@require_http_methods(["POST"])
def processar_pagamento_pix(request):
    """
    Endpoint para gerar pagamento PIX
    
    POST /api/payments/pix/
    {
        "amount": 10000,
        "customer": {
            "name": "João Silva",
            "email": "joao@example.com",
            "cpf": "12345678900"
        },
        "expiration_seconds": 3600
    }
    """
    try:
        data = json.loads(request.body)
        
        result = gateway.pix.create(
            amount=data['amount'],
            customer=data['customer'],
            expiration_seconds=data.get('expiration_seconds', 3600)
        )
        
        # Salvar no banco
        # payment = Payment.objects.create(
        #     payment_id=result['payment_id'],
        #     status='waiting',
        #     amount=data['amount'],
        #     ...
        # )
        
        return JsonResponse({
            'success': True,
            'payment_id': result['payment_id'],
            'qr_code': result['additional_data']['qr_code'],
            'qr_code_base64': result['additional_data']['qr_code_base64'],
        })
        
    except Exception as e:
        return JsonResponse({
            'success': False,
            'error': str(e)
        }, status=500)


@require_http_methods(["GET"])
def consultar_pagamento(request, payment_id):
    """
    Endpoint para consultar status de pagamento
    
    GET /api/payments/status/<payment_id>/
    """
    try:
        result = gateway.query(payment_id)
        
        payment_data = result.get('Payment', {})
        
        return JsonResponse({
            'success': True,
            'payment_id': payment_id,
            'status': payment_data.get('Status'),
            'return_message': payment_data.get('ReturnMessage'),
            'data': result
        })
        
    except Exception as e:
        return JsonResponse({
            'success': False,
            'error': str(e)
        }, status=500)


@csrf_exempt
@require_http_methods(["POST"])
def webhook_cielo(request):
    """
    Endpoint para receber webhooks da Cielo
    
    POST /webhook/cielo/
    
    Configure esta URL no painel da Cielo
    """
    try:
        data = json.loads(request.body)
        
        # Validar webhook
        if not webhook_handler.validate_webhook(data):
            return HttpResponse(status=400)
        
        # Processar webhook
        result = webhook_handler.process(data)
        
        if result['processed']:
            payment_id = result['payment_id']
            new_status = result['new_status']
            
            # Atualizar banco de dados
            # Payment.objects.filter(payment_id=payment_id).update(
            #     status=new_status
            # )
            
            print(f"Webhook processado: {payment_id} -> {new_status}")
        
        return HttpResponse(status=200)
        
    except Exception as e:
        print(f"Erro ao processar webhook: {e}")
        return HttpResponse(status=500)


# Registrar callbacks para webhooks
def on_payment_approved(payment_id, payment_data):
    """Callback quando pagamento for aprovado"""
    print(f"Pagamento aprovado: {payment_id}")
    # Enviar email de confirmação
    # send_confirmation_email(payment_id)


def on_payment_denied(payment_id, payment_data):
    """Callback quando pagamento for negado"""
    print(f"Pagamento negado: {payment_id}")
    # Notificar cliente


webhook_handler.register_callback('approved', on_payment_approved)
webhook_handler.register_callback('denied', on_payment_denied)
