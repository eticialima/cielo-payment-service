"""
Django-Cielo - Biblioteca de integração com a API Cielo para Django
"""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="django-cielo",
    version="1.0.0",
    author="DMC Equipamentos",
    author_email="leticia.lima@dmcgroup.com.br",
    description="Biblioteca Django para integração com gateway de pagamento Cielo",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/DMC-Equipamentos/django-cielo",
    packages=find_packages(exclude=["tests", "examples"]),
    include_package_data=True,
    package_data={
        'django_cielo': ['migrations/*.py'],
    },
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Framework :: Django",
        "Framework :: Django :: 3.2",
        "Framework :: Django :: 4.0",
        "Framework :: Django :: 4.1",
        "Framework :: Django :: 4.2",
        "Framework :: Django :: 5.0",
    ],
    python_requires=">=3.8",
    install_requires=[
        "Django>=4.2",
        "requests>=2.31",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0",
            "pytest-django>=4.5",
            "black>=23.0",
            "flake8>=6.0",
            "mypy>=1.0",
        ],
    },
    keywords="django cielo payment gateway credit-card pix ecommerce",
    project_urls={
        "Bug Reports": "https://github.com/DMC-Equipamentos/django-cielo/issues",
        "Source": "https://github.com/DMC-Equipamentos/django-cielo",
        "Documentation": "https://github.com/DMC-Equipamentos/django-cielo#readme",
    },
)
