"""
Handler de webhooks da Cielo
"""

from typing import Dict, Any, Optional, Callable
from django_cielo.handlers.status import StatusHandler
from django_cielo.utils import log_payment_info


class WebhookHandler:
    """
    Handler para processar webhooks da Cielo
    
    Exemplo de uso:
        from django_cielo import CieloGateway
        from django_cielo.handlers import WebhookHandler
        
        gateway = CieloGateway()
        webhook_handler = WebhookHandler(gateway)
        
        # No seu endpoint de webhook
        @csrf_exempt
        def cielo_webhook(request):
            data = json.loads(request.body)
            result = webhook_handler.process(data)
            
            if result['processed']:
                # Atualizar seu banco de dados
                update_payment_status(
                    result['payment_id'],
                    result['new_status']
                )
            
            return HttpResponse(status=200)
    """
    
    # Mapeamento de ChangeType da Cielo
    CHANGE_TYPES = {
        1: "Status da transação mudou",
        2: "Recorrência criada",
        3: "Status do Antifraude mudou",
        4: "Status do pagamento recorrente mudou",
        5: "Cancelamento negado",
        7: "Notificação de chargeback",
        8: "Alerta de fraude",
        25: "Transação cancelada ou estornada parcialmente"
    }
    
    def __init__(self, gateway):
        """
        Args:
            gateway: Instância de CieloGateway
        """
        self.gateway = gateway
        self._callbacks = {}
    
    def register_callback(self, status: str, callback: Callable):
        """
        Registra callback para ser executado quando determinado status for recebido
        
        Args:
            status: Status que deve acionar o callback ('approved', 'denied', etc)
            callback: Função a ser executada callback(payment_id, payment_data)
        """
        self._callbacks[status] = callback
    
    def process(self, webhook_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Processa webhook recebido da Cielo
        
        Args:
            webhook_data: Payload do webhook
            
        Returns:
            Dict com informações processadas:
            {
                'processed': True/False,
                'payment_id': 'xxx',
                'change_type': 1,
                'change_description': '...',
                'old_status': 'pending',
                'new_status': 'approved',
                'cielo_status': 2,
                'payment_data': {...}
            }
        """
        log_payment_info("Processando webhook da Cielo")
        
        # Extrair PaymentId - pode estar em Payment.PaymentId ou direto na raiz
        payment_data_nested = webhook_data.get('Payment', {})
        payment_id = payment_data_nested.get('PaymentId') or webhook_data.get('PaymentId')
        change_type = webhook_data.get('ChangeType')
        
        if not payment_id:
            log_payment_info("PaymentId nao encontrado no webhook", debug=True)
            return {
                'processed': False,
                'error': 'PaymentId não encontrado'
            }
        
        change_desc = self.CHANGE_TYPES.get(change_type, f"Tipo desconhecido: {change_type}")
        
        log_payment_info(
            "Webhook identificado",
            {
                "payment_id": payment_id,
                "change_type": change_type,
                "description": change_desc
            }
        )
        
        # Consultar status atualizado na API
        try:
            payment_info = self.gateway.query(payment_id)
        except Exception as e:
            log_payment_info(f"Erro ao consultar pagamento: {str(e)}", debug=True)
            return {
                'processed': False,
                'error': f'Falha ao consultar API: {str(e)}',
                'payment_id': payment_id
            }
        
        # Extrair status
        payment_data_query = payment_info.get('Payment', {})
        cielo_status = payment_data_query.get('Status')
        return_code = payment_data_query.get('ReturnCode', '')
        return_message = payment_data_query.get('ReturnMessage', '')
        
        # Mapear para status interno
        new_status = StatusHandler.from_cielo(cielo_status)
        
        log_payment_info(
            "Status atualizado",
            {
                "payment_id": payment_id,
                "cielo_status": cielo_status,
                "internal_status": new_status,
                "return_code": return_code,
                "return_message": return_message
            }
        )
        
        # Executar callback se registrado
        if new_status in self._callbacks:
            try:
                self._callbacks[new_status](payment_id, payment_info)
                log_payment_info(f"Callback executado para status: {new_status}")
            except Exception as e:
                log_payment_info(f"Erro ao executar callback: {str(e)}", debug=True)
        
        return {
            'processed': True,
            'payment_id': payment_id,
            'change_type': change_type,
            'change_description': change_desc,
            'new_status': new_status,
            'cielo_status': cielo_status,
            'return_code': return_code,
            'return_message': return_message,
            'payment_data': payment_info
        }
    
    def validate_webhook(self, webhook_data: Dict[str, Any]) -> bool:
        """
        Valida se webhook tem estrutura válida
        
        Args:
            webhook_data: Payload do webhook
            
        Returns:
            True se válido, False caso contrário
        """
        # Verificar se tem PaymentId
        has_payment_nested = 'Payment' in webhook_data and 'PaymentId' in webhook_data.get('Payment', {})
        has_payment_direct = 'PaymentId' in webhook_data
        
        if not (has_payment_nested or has_payment_direct):
            return False
        
        # Verificar se tem ChangeType
        if 'ChangeType' not in webhook_data:
            return False
        
        return True
