"""
Handler de gerenciamento de status de pagamentos
"""

from typing import Dict, Any


class StatusHandler:
    """
    Gerenciador de status de pagamentos
    
    Mantém consistência entre status da Cielo e sistema interno
    """
    
    # Códigos de status da Cielo
    NOT_FINISHED = 0          # Aguardando atualização
    AUTHORIZED = 1            # Autorizado (apto a captura)
    PAYMENT_CONFIRMED = 2     # Pagamento confirmado
    DENIED = 3                # Negado
    VOIDED = 10               # Cancelado
    REFUNDED = 11             # Reembolsado
    PENDING = 12              # Pendente
    ABORTED = 13              # Abortado
    SCHEDULED = 20            # Agendado (recorrência)
    
    # Mapeamento de status Cielo (numérico) para status interno
    STATUS_MAP = {
        0: 'pending',         # NOT_FINISHED - Aguardando atualização
        1: 'approved',        # AUTHORIZED - Autorizado (apto a captura)
        2: 'approved',        # PAYMENT_CONFIRMED - Pagamento confirmado
        3: 'denied',          # DENIED - Negado por Autorizador
        10: 'canceled',       # VOIDED - Cancelado
        11: 'refunded',       # REFUNDED - Reembolsado/Estornado
        12: 'waiting',        # PENDING - Aguardando retorno (PIX, boleto)
        13: 'denied',         # ABORTED - Cancelado por falha/antifraude
        20: 'pending'         # SCHEDULED - Recorrência agendada
    }
    
    # Status válidos e suas descrições
    VALID_STATUSES = {
        'pending': 'Pendente',
        'processing': 'Processando',
        'approved': 'Aprovado',
        'denied': 'Negado',
        'canceled': 'Cancelado',
        'refunded': 'Reembolsado',
        'waiting': 'Aguardando Pagamento (PIX)'
    }
    
    @classmethod
    def from_cielo(cls, cielo_status: int) -> str:
        """
        Converte status numérico da Cielo para status interno
        
        Args:
            cielo_status: Status numérico da Cielo (0-20)
            
        Returns:
            Status interno ('pending', 'approved', etc)
        """
        return cls.STATUS_MAP.get(cielo_status, 'pending')
    
    @classmethod
    def to_display(cls, internal_status: str) -> str:
        """
        Converte status interno para texto de exibição
        
        Args:
            internal_status: Status interno ou código Cielo (como string)
            
        Returns:
            Texto de exibição
        """
        # Se for um número (string), converter primeiro
        if internal_status.isdigit():
            internal_status = cls.from_cielo(int(internal_status))
        
        return cls.VALID_STATUSES.get(internal_status, 'Desconhecido')
    
    @classmethod
    def is_final(cls, status: str) -> bool:
        """
        Verifica se status é final (não pode mudar mais)
        
        Args:
            status: Status interno
            
        Returns:
            True se for status final
        """
        final_statuses = ['approved', 'denied', 'canceled', 'refunded']
        return status in final_statuses
    
    @classmethod
    def is_success(cls, status: str) -> bool:
        """
        Verifica se status indica sucesso
        
        Args:
            status: Status interno
            
        Returns:
            True se for sucesso
        """
        return status == 'approved'
    
    @classmethod
    def can_retry(cls, status: str) -> bool:
        """
        Verifica se transação pode ser retentada
        
        Args:
            status: Status interno
            
        Returns:
            True se pode retentar
        """
        retryable_statuses = ['denied', 'canceled']
        return status in retryable_statuses
    
    @classmethod
    def get_user_message(cls, status: str, return_message: str = None) -> str:
        """
        Gera mensagem amigável para o usuário baseada no status
        
        Args:
            status: Status interno
            return_message: Mensagem da Cielo (opcional)
            
        Returns:
            Mensagem para o usuário
        """
        messages = {
            'approved': 'Pagamento aprovado com sucesso!',
            'denied': f'Pagamento negado. {return_message or "Verifique os dados e tente novamente."}',
            'pending': 'Pagamento pendente. Aguarde o processamento.',
            'processing': 'Processando pagamento. Aguarde alguns instantes.',
            'canceled': 'Pagamento cancelado.',
            'refunded': 'Pagamento reembolsado. O valor foi devolvido.',
            'waiting': 'Aguardando pagamento PIX. Escaneie o QR Code para pagar.'
        }
        
        return messages.get(status, 'Status desconhecido. Entre em contato com o suporte.')
    
    @classmethod
    def get_status_info(cls, cielo_status: int, return_code: str = None) -> Dict[str, Any]:
        """
        Retorna informações completas sobre o status
        
        Args:
            cielo_status: Status numérico da Cielo
            return_code: Código de retorno (opcional)
            
        Returns:
            Dict com informações do status:
            {
                'internal_status': 'approved',
                'cielo_status': 2,
                'display_text': 'Aprovado',
                'is_final': True,
                'is_success': True,
                'can_retry': False,
                'user_message': '...'
            }
        """
        internal = cls.from_cielo(cielo_status)
        
        return {
            'internal_status': internal,
            'cielo_status': cielo_status,
            'display_text': cls.to_display(internal),
            'is_final': cls.is_final(internal),
            'is_success': cls.is_success(internal),
            'can_retry': cls.can_retry(internal),
            'user_message': cls.get_user_message(internal),
            'return_code': return_code
        }
