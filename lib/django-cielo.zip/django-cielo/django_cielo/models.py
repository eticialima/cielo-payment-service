"""
Models opcionais para integração com Cielo
"""

import random
import string
from django.db import models
from django.utils import timezone
from django.contrib.contenttypes.fields import GenericForeignKey
from django.contrib.contenttypes.models import ContentType


class BaseCheckoutLink(models.Model):
    """
    Model abstrato para links de checkout/pagamento.
    
    Pode ser usado diretamente ou herdado para customização:
    
    Exemplo de uso direto:
        from django_cielo.models import CheckoutLink
        link = CheckoutLink.objects.create(amount=10000)
        
    Exemplo de herança:
        class MyCheckoutLink(BaseCheckoutLink):
            order = models.ForeignKey(Order, on_delete=models.CASCADE)
            custom_field = models.CharField(max_length=100)
    """
    key = models.CharField(
        max_length=100, 
        unique=True, 
        db_index=True,
        help_text="Chave única do checkout (gerada automaticamente)"
    )
    
    amount = models.BigIntegerField(
        default=0,
        help_text="Valor em centavos (ex: 10000 = R$ 100,00)"
    )
    
    created_at = models.DateTimeField(auto_now_add=True)
    
    expires_at = models.DateTimeField(
        help_text="Data de expiração do link"
    )
    
    used = models.BooleanField(
        default=False,
        db_index=True,
        help_text="Indica se o link já foi utilizado"
    )
    
    canceled = models.BooleanField(
        default=False,
        db_index=True,
        help_text="Indica se o link foi cancelado"
    )

    def is_valid(self):
        """Verifica se o link é válido para uso"""
        return (
            not self.used
            and not self.canceled
            and self.expires_at
            and timezone.now() < self.expires_at
        )

    def validation_status(self):
        """Retorna status de validação legível"""
        if self.used:
            return "Link já usado"
        if self.canceled:
            return "Link cancelado"
        if not self.expires_at:
            return "Sem data de expiração"
        if timezone.now() > self.expires_at:
            return "Link expirado"
        return "Válido"

    def save(self, *args, **kwargs):
        if not self.key:
            self.key = ''.join(random.choices(string.ascii_letters + string.digits, k=32))
        if not self.expires_at:
            self.expires_at = timezone.now() + timezone.timedelta(hours=24)
        super().save(*args, **kwargs)

    def __str__(self):
        return f"Checkout {self.key[:8]}... - R$ {self.amount/100:.2f}"

    class Meta:
        abstract = True


class CheckoutLink(BaseCheckoutLink):
    """
    Implementação concreta de CheckoutLink.
    Pode ser usada diretamente ou servir como exemplo.
    """
    
    class Meta:
        verbose_name = "01 - Checkout Link"
        verbose_name_plural = "01 - Checkout Links"
        ordering = ["-created_at"]


class BasePaymentTransaction(models.Model):
    """
    Model abstrato para transações de pagamento Cielo.
    
    Use diretamente ou herde para customizar:
    
    Exemplo de uso direto:
        from django_cielo.models import PaymentTransaction
        transaction = PaymentTransaction.objects.create(...)
        
    Exemplo de herança com relacionamento customizado:
        class MyTransaction(BasePaymentTransaction):
            order = models.ForeignKey(Order, on_delete=models.PROTECT)
            custom_metadata = models.JSONField(default=dict)
    """
    STATUS_CHOICES = (
        ('pending', 'Pendente'),
        ('waiting', 'Aguardando Pagamento'),
        ('processing', 'Processando'),
        ('approved', 'Aprovado'),
        ('denied', 'Negado'),
        ('canceled', 'Cancelado'),
        ('refunded', 'Reembolsado'),
    )
    
    PAYMENT_METHOD_CHOICES = (
        ('credit_card', 'Cartão de Crédito'),
        ('debit_card', 'Cartão de Débito'),
        ('pix', 'PIX')
    )
    
    GATEWAY_CHOICES = (
        ('cielo', 'Cielo'),
    )
    
    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default='pending',
        db_index=True
    )
    
    payment_method = models.CharField(
        max_length=20,
        choices=PAYMENT_METHOD_CHOICES,
        default='credit_card',
        db_index=True
    )
    
    gateway_provider = models.CharField(
        max_length=20,
        choices=GATEWAY_CHOICES,
        default='cielo',
        help_text="Gateway de pagamento utilizado"
    )
    
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)
    
    payment_date = models.DateTimeField(
        null=True,
        blank=True,
        help_text="Data de aprovação do pagamento"
    )
    
    amount = models.BigIntegerField(
        help_text="Valor em centavos (ex: 10000 = R$ 100,00)"
    )
    
    transaction_id = models.CharField(
        max_length=100,
        blank=True,
        null=True,
        unique=True,
        db_index=True,
        help_text="ID da transação no gateway Cielo"
    )
    
    payment_response = models.JSONField(
        blank=True,
        null=True,
        help_text="Resposta completa da API Cielo"
    )
    
    error_message = models.TextField(
        blank=True,
        null=True,
        help_text="Mensagem de erro em caso de falha"
    )
    
    last_update = models.DateTimeField(auto_now=True)

    def save(self, *args, **kwargs):
        if self.status == 'approved' and not self.payment_date:
            self.payment_date = timezone.now()
        super().save(*args, **kwargs)

    def __str__(self):
        return f"Transaction {self.id} - {self.status} - R$ {self.amount/100:.2f}"
    
    class Meta:
        abstract = True


class PaymentTransaction(BasePaymentTransaction):
    """
    Implementação concreta de PaymentTransaction.
    Usa GenericForeignKey para relacionamento flexível.
    """
    # Relacionamento genérico (pode apontar para qualquer model)
    content_type = models.ForeignKey(
        ContentType,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        help_text="Tipo do objeto relacionado (ex: CheckoutLink, Order)"
    )
    object_id = models.PositiveIntegerField(
        null=True,
        blank=True,
        help_text="ID do objeto relacionado"
    )
    content_object = GenericForeignKey('content_type', 'object_id')
    
    class Meta:
        verbose_name = "02 - Transação de Pagamento"
        verbose_name_plural = "02 - Transações de Pagamento"
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['content_type', 'object_id']),
        ]


class BasePaymentAttempt(models.Model):
    """
    Model abstrato para tentativas de pagamento.
    Registra cada tentativa de processar um pagamento.
    """
    attempted_at = models.DateTimeField(auto_now_add=True, db_index=True)
    
    status = models.CharField(max_length=20)
    
    response_data = models.JSONField(
        blank=True,
        null=True,
        help_text="Dados da resposta da tentativa"
    )
    
    error_code = models.CharField(
        max_length=50,
        blank=True,
        null=True
    )
    
    error_message = models.TextField(
        blank=True,
        null=True
    )

    def __str__(self):
        return f"Attempt {self.id} - {self.status} - {self.attempted_at}"

    class Meta:
        abstract = True


class PaymentAttempt(BasePaymentAttempt):
    """
    Implementação concreta de PaymentAttempt.
    """
    transaction = models.ForeignKey(
        PaymentTransaction,
        on_delete=models.CASCADE,
        related_name="attempts"
    )
    
    class Meta:
        verbose_name = "03 - Tentativa de Pagamento"
        verbose_name_plural = "03 - Tentativas de Pagamento"
        ordering = ['-attempted_at']


class BasePaymentWebhook(models.Model):
    """
    Model abstrato para webhooks da Cielo.
    Armazena notificações recebidas do gateway.
    """
    received_at = models.DateTimeField(auto_now_add=True, db_index=True)
    
    event_type = models.CharField(
        max_length=50,
        db_index=True,
        help_text="Tipo de evento (ex: payment.approved, payment.canceled)"
    )
    
    payload = models.JSONField(
        help_text="Payload completo do webhook"
    )
    
    processed = models.BooleanField(
        default=False,
        db_index=True,
        help_text="Indica se o webhook foi processado"
    )
    
    processing_error = models.TextField(
        blank=True,
        null=True
    )

    def __str__(self):
        return f"Webhook {self.id} - {self.event_type} - {self.received_at}"

    class Meta:
        abstract = True


class PaymentWebhook(BasePaymentWebhook):
    """
    Implementação concreta de PaymentWebhook.
    """
    transaction = models.ForeignKey(
        PaymentTransaction,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="webhooks"
    )
    
    class Meta:
        verbose_name = "04 - Webhook de Pagamento"
        verbose_name_plural = "04 - Webhooks de Pagamento"
        ordering = ['-received_at']
