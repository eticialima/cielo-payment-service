"""
Configurações da biblioteca Django-Cielo
"""

import os
from typing import Dict, Any
from django.conf import settings


class CieloSettings:
    """
    Gerenciador de configurações da biblioteca
    
    Configuração via settings.py:
        DJANGO_CIELO = {
            'MERCHANT_ID': 'seu_merchant_id',
            'MERCHANT_KEY': 'sua_merchant_key',
            'SANDBOX': True,  # False para produção
            'PIX_MOCK_MODE': False,  # True para simular PIX em sandbox
            'TIMEOUT': 30,  # Timeout das requisições em segundos
            'DEBUG': False,  # Habilita logs detalhados
        }
    
    Ou via variáveis de ambiente:
        CIELO_MERCHANT_ID=xxx
        CIELO_MERCHANT_KEY=xxx
        CIELO_SANDBOX=true
        PIX_MOCK_MODE=false
    """
    
    # Configurações padrão
    DEFAULTS = {
        'MERCHANT_ID': '',
        'MERCHANT_KEY': '',
        'SANDBOX': True,
        'PIX_MOCK_MODE': False,
        'TIMEOUT': 30,
        'DEBUG': False,
        'SOFT_DESCRIPTOR': 'DMC*FEIRA',  # Descrição na fatura do cartão
        'SKIP_CARD_VALIDATION': False,  # Pular validação Luhn para cartões de teste
    }
    
    def __init__(self, custom_config: Dict[str, Any] = None):
        """
        Inicializa configurações
        
        Ordem de prioridade:
        1. custom_config passado no __init__
        2. settings.DJANGO_CIELO
        3. Variáveis de ambiente
        4. DEFAULTS
        """
        self._config = self._load_config(custom_config)
    
    def _load_config(self, custom_config: Dict[str, Any] = None) -> Dict[str, Any]:
        """Carrega configurações de múltiplas fontes"""
        config = self.DEFAULTS.copy()
        
        # 1. Carregar do settings.py do Django
        django_settings = getattr(settings, 'DJANGO_CIELO', {})
        config.update(django_settings)
        
        # 2. Carregar de variáveis de ambiente (sobrescreve settings.py)
        env_config = {
            'MERCHANT_ID': os.getenv('CIELO_MERCHANT_ID', config['MERCHANT_ID']),
            'MERCHANT_KEY': os.getenv('CIELO_MERCHANT_KEY', config['MERCHANT_KEY']),
            'SANDBOX': self._str_to_bool(os.getenv('CIELO_SANDBOX', str(config['SANDBOX']))),
            'PIX_MOCK_MODE': self._str_to_bool(os.getenv('PIX_MOCK_MODE', str(config['PIX_MOCK_MODE']))),
            'TIMEOUT': int(os.getenv('CIELO_TIMEOUT', str(config['TIMEOUT']))),
            'DEBUG': self._str_to_bool(os.getenv('CIELO_DEBUG', str(config['DEBUG']))),
        }
        config.update(env_config)
        
        # 3. Sobrescrever com configuração customizada (maior prioridade)
        if custom_config:
            config.update(custom_config)
        
        return config
    
    @staticmethod
    def _str_to_bool(value: str) -> bool:
        """Converte string para booleano"""
        return value.lower() in ('true', '1', 'yes', 'on')
    
    def get(self, key: str, default: Any = None) -> Any:
        """Obtém uma configuração"""
        return self._config.get(key, default)
    
    @property
    def merchant_id(self) -> str:
        return self._config['MERCHANT_ID']
    
    @property
    def merchant_key(self) -> str:
        return self._config['MERCHANT_KEY']
    
    @property
    def is_sandbox(self) -> bool:
        return self._config['SANDBOX']
    
    @property
    def is_production(self) -> bool:
        return not self._config['SANDBOX']
    
    @property
    def pix_mock_mode(self) -> bool:
        return self._config['PIX_MOCK_MODE']
    
    @property
    def timeout(self) -> int:
        return self._config['TIMEOUT']
    
    @property
    def debug(self) -> bool:
        return self._config['DEBUG']
    
    @property
    def soft_descriptor(self) -> str:
        return self._config.get('SOFT_DESCRIPTOR', 'DMC*FEIRA')
    
    @property
    def skip_card_validation(self) -> bool:
        return self._config.get('SKIP_CARD_VALIDATION', False)
    
    @property
    def base_url(self) -> str:
        """URL base para criação de pagamentos"""
        if self.is_sandbox:
            return 'https://apisandbox.cieloecommerce.cielo.com.br'
        return 'https://api.cieloecommerce.cielo.com.br'
    
    @property
    def query_url(self) -> str:
        """URL base para consultas"""
        if self.is_sandbox:
            return 'https://apiquerysandbox.cieloecommerce.cielo.com.br/1/sales/'
        return 'https://apiquery.cieloecommerce.cielo.com.br/1/sales/'
    
    @property
    def sales_url(self) -> str:
        """URL completa para vendas"""
        return f"{self.base_url}/1/sales/"
    
    def validate(self):
        """
        Valida se as configurações mínimas estão presentes
        
        Raises:
            ValueError: Se configurações obrigatórias estiverem faltando
        """
        if not self.merchant_id:
            raise ValueError(
                "MERCHANT_ID não configurado. "
                "Defina DJANGO_CIELO['MERCHANT_ID'] no settings.py "
                "ou a variável de ambiente CIELO_MERCHANT_ID"
            )
        
        if not self.merchant_key:
            raise ValueError(
                "MERCHANT_KEY não configurado. "
                "Defina DJANGO_CIELO['MERCHANT_KEY'] no settings.py "
                "ou a variável de ambiente CIELO_MERCHANT_KEY"
            )
    
    def __repr__(self):
        masked_key = f"{self.merchant_key[:10]}...{self.merchant_key[-4:]}" if self.merchant_key else "NOT SET"
        return (
            f"CieloSettings("
            f"merchant_id='{self.merchant_id}', "
            f"merchant_key='{masked_key}', "
            f"sandbox={self.is_sandbox})"
        )


# Instância global padrão (pode ser sobrescrita)
default_settings = CieloSettings()
