"""
Gateway principal da Cielo - Ponto de entrada da biblioteca
"""

import requests
from typing import Dict, Any, Optional
from django_cielo.settings import CieloSettings
from django_cielo.payment.credit_card import CreditCardPayment
from django_cielo.payment.pix import PixPayment
from django_cielo.exceptions import CieloAPIError, CieloTimeoutError, CieloNetworkError
from django_cielo.utils import log_payment_info


class CieloGateway:
    """
    Gateway principal para integração com a API Cielo
    
    Exemplo de uso:
        gateway = CieloGateway()
        
        # Pagamento com cartão
        result = gateway.credit_card.create(
            card_number='4000000000001091',
            cardholder_name='TESTE',
            expiration_month='12',
            expiration_year='30',
            security_code='123',
            amount=10000,
            customer={'name': 'João', 'email': 'joao@example.com'}
        )
        
        # Pagamento PIX
        result = gateway.pix.create(
            amount=10000,
            customer={'name': 'João', 'email': 'joao@example.com'}
        )
        
        # Consultar pagamento
        status = gateway.query(payment_id='xxx-xxx-xxx')
    """
    
    def __init__(self, config: Dict[str, Any] = None):
        """
        Inicializa o gateway
        
        Args:
            config: Configurações customizadas (opcional)
                   Se não fornecido, usa settings.DJANGO_CIELO
        """
        self.settings = CieloSettings(config)
        self.settings.validate()
        
        # Inicializar handlers de pagamento
        self._credit_card = None
        self._pix = None
        
        log_payment_info(
            "CieloGateway inicializado",
            {
                "environment": "SANDBOX" if self.settings.is_sandbox else "PRODUCTION",
                "sales_url": self.settings.sales_url,
                "query_url": self.settings.query_url,
            }
        )
    
    @property
    def credit_card(self) -> CreditCardPayment:
        """Acesso ao handler de cartão de crédito"""
        if self._credit_card is None:
            self._credit_card = CreditCardPayment(self)
        return self._credit_card
    
    @property
    def pix(self) -> PixPayment:
        """Acesso ao handler de PIX"""
        if self._pix is None:
            self._pix = PixPayment(self)
        return self._pix
    
    def get_headers(self) -> Dict[str, str]:
        """
        Gera headers para requisições à API Cielo
        
        Returns:
            Dict com headers necessários
        """
        return {
            "accept": "application/json",
            "MerchantId": self.settings.merchant_id,
            "MerchantKey": self.settings.merchant_key,
            "Content-Type": "application/json"
        }
    
    def make_request(
        self,
        method: str,
        url: str,
        data: Optional[Dict[str, Any]] = None,
        timeout: Optional[int] = None
    ) -> Dict[str, Any]:
        """
        Faz requisição HTTP para a API Cielo
        
        Args:
            method: Método HTTP (GET, POST, etc)
            url: URL completa
            data: Dados para enviar (para POST/PUT)
            timeout: Timeout customizado (usa settings.timeout se None)
            
        Returns:
            Resposta JSON da API
            
        Raises:
            CieloAPIError: Se a API retornar erro
            CieloTimeoutError: Se houver timeout
            CieloNetworkError: Se houver erro de rede
        """
        headers = self.get_headers()
        timeout = timeout or self.settings.timeout
        
        try:
            log_payment_info(
                f"Requisição {method} para Cielo",
                {"url": url, "timeout": timeout}
            )
            
            if method.upper() == 'GET':
                response = requests.get(url, headers=headers, timeout=timeout)
            elif method.upper() == 'POST':
                response = requests.post(url, json=data, headers=headers, timeout=timeout)
            elif method.upper() == 'PUT':
                response = requests.put(url, json=data, headers=headers, timeout=timeout)
            else:
                raise ValueError(f"Método HTTP não suportado: {method}")
            
            log_payment_info(
                "Resposta da Cielo recebida",
                {"status_code": response.status_code}
            )
            
            # Tentar parsear resposta JSON
            try:
                response_data = response.json()
            except ValueError:
                response_data = {"raw_response": response.text}
            
            # Verificar se houve erro HTTP
            if response.status_code not in [200, 201]:
                from django_cielo.utils import parse_cielo_error
                error = parse_cielo_error(response_data)
                
                raise CieloAPIError(
                    error['message'],
                    code=error['code'],
                    status_code=response.status_code,
                    details=response_data
                )
            
            return response_data
            
        except requests.exceptions.Timeout:
            log_payment_info("Timeout na requisição para Cielo", debug=True)
            raise CieloTimeoutError(
                "Timeout na comunicação com a Cielo. Tente novamente."
            )
        
        except requests.exceptions.ConnectionError as e:
            log_payment_info(f"Erro de conexão: {str(e)}", debug=True)
            raise CieloNetworkError(
                "Erro de conexão com a Cielo. Verifique sua internet."
            )
        
        except CieloAPIError:
            raise  # Re-raise CieloAPIError
        
        except Exception as e:
            log_payment_info(f"Erro inesperado: {str(e)}", debug=True)
            raise CieloAPIError(
                f"Erro inesperado: {str(e)}",
                details={"exception": str(type(e).__name__)}
            )
    
    def query(self, payment_id: str) -> Dict[str, Any]:
        """
        Consulta status de um pagamento pelo PaymentId
        
        Args:
            payment_id: ID da transação na Cielo
            
        Returns:
            Dados completos do pagamento
            
        Raises:
            CieloAPIError: Se houver erro na consulta
        """
        url = f"{self.settings.query_url}{payment_id}"
        
        log_payment_info(
            "Consultando pagamento",
            {"payment_id": payment_id, "url": url}
        )
        
        response = self.make_request('GET', url)
        
        log_payment_info(
            "Pagamento consultado com sucesso",
            {"payment_id": payment_id}
        )
        
        return response
    
    def cancel(self, payment_id: str, amount: Optional[int] = None) -> Dict[str, Any]:
        """
        Cancela ou estorna um pagamento
        
        Args:
            payment_id: ID da transação na Cielo
            amount: Valor a cancelar em centavos (None = cancelamento total)
            
        Returns:
            Dados do cancelamento
            
        Raises:
            CieloAPIError: Se houver erro no cancelamento
        """
        url = f"{self.settings.sales_url}{payment_id}/void"
        
        data = {}
        if amount is not None:
            data['Amount'] = amount
        
        log_payment_info(
            "Cancelando pagamento",
            {"payment_id": payment_id, "amount": amount}
        )
        
        response = self.make_request('PUT', url, data=data if data else None)
        
        log_payment_info(
            "Pagamento cancelado com sucesso",
            {"payment_id": payment_id}
        )
        
        return response
    
    def capture(self, payment_id: str, amount: Optional[int] = None) -> Dict[str, Any]:
        """
        Captura um pagamento previamente autorizado
        
        Args:
            payment_id: ID da transação na Cielo
            amount: Valor a capturar em centavos (None = captura total)
            
        Returns:
            Dados da captura
            
        Raises:
            CieloAPIError: Se houver erro na captura
        """
        url = f"{self.settings.sales_url}{payment_id}/capture"
        
        data = {}
        if amount is not None:
            data['Amount'] = amount
        
        log_payment_info(
            "Capturando pagamento",
            {"payment_id": payment_id, "amount": amount}
        )
        
        response = self.make_request('PUT', url, data=data if data else None)
        
        log_payment_info(
            "Pagamento capturado com sucesso",
            {"payment_id": payment_id}
        )
        
        return response
    
    def __repr__(self):
        env = "SANDBOX" if self.settings.is_sandbox else "PRODUCTION"
        return f"CieloGateway(environment={env})"
