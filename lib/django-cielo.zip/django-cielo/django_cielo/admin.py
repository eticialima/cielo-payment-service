"""
Admin classes para models do django-cielo.

Registra automaticamente quando você adiciona 'django_cielo' no INSTALLED_APPS.

Para customizar, você pode:
1. Usar como está (admin automático)
2. Desregistrar e re-registrar com customizações
3. Herdar e estender

Exemplo de customização:
    # payment/admin.py
    from django.contrib import admin
    from django_cielo.admin import CheckoutLinkAdmin as BaseCheckoutLinkAdmin
    from payment.models import CheckoutLink
    
    # Desregistrar o admin padrão
    admin.site.unregister(CheckoutLink)
    
    # Registrar com customizações
    @admin.register(CheckoutLink)
    class CheckoutLinkAdmin(BaseCheckoutLinkAdmin):
        def get_link_url(self, obj):
            # Customizar URL
            return f"https://meusite.com/checkout?c={obj.key}"
"""

from django.contrib import admin
from django.contrib.contenttypes.admin import GenericTabularInline
from django.utils.html import format_html
from django.utils.http import urlsafe_base64_encode
from django.conf import settings
from django_cielo.handlers import StatusHandler


# =========================================
# INLINES (usando GenericForeignKey para Transaction, FK normal para Attempt/Webhook)
# =========================================

class PaymentTransactionInline(GenericTabularInline):
    """Inline para transações usando GenericForeignKey"""
    from django_cielo.models import PaymentTransaction
    model = PaymentTransaction
    ct_field = 'content_type'
    ct_fk_field = 'object_id'
    extra = 0
    readonly_fields = ('created_at', 'payment_date', 'last_update')
    fields = ('status', 'payment_method', 'amount', 'transaction_id', 'created_at', 'payment_date')
    can_delete = False
    
    def has_add_permission(self, request, obj=None):
        return False


class PaymentAttemptInline(admin.TabularInline):
    """Inline para tentativas de pagamento (FK normal para Transaction)"""
    from django_cielo.models import PaymentAttempt
    model = PaymentAttempt
    fk_name = 'transaction'
    extra = 0
    readonly_fields = ('attempted_at',)
    fields = ('attempted_at', 'status', 'error_code', 'error_message')
    can_delete = False
    
    def has_add_permission(self, request, obj=None):
        return False


class PaymentWebhookInline(admin.TabularInline):
    """Inline para webhooks (FK normal para Transaction)"""
    from django_cielo.models import PaymentWebhook
    model = PaymentWebhook
    fk_name = 'transaction'
    extra = 0
    readonly_fields = ('received_at',)
    fields = ('received_at', 'event_type', 'processed', 'processing_error')
    can_delete = False
    
    def has_add_permission(self, request, obj=None):
        return False


# =========================================
# CHECKOUT LINK ADMIN
# =========================================

class CheckoutLinkAdmin(admin.ModelAdmin):
    """
    Admin para CheckoutLink.
    Override get_link_url() para customizar o domínio.
    """
    list_display = (
        'key',
        'get_amount',
        'created_at',
        'expires_at',
        'get_status_badge',
        'validation_status',
    )

    list_filter = ('used', 'canceled', 'created_at', 'expires_at')
    search_fields = ('key',)

    readonly_fields = (
        'key',
        'created_at',
        'expires_at',
        'get_amount',
        'validation_status',
        'get_link_url'
    )

    fieldsets = (
        ('Link', {'fields': ('key', 'get_link_url')}),
        ('Valor', {'fields': ('amount', 'get_amount')}),
        ('Datas', {'fields': ('created_at', 'expires_at')}),
        ('Status', {'fields': ('used', 'canceled', 'validation_status')}),
    )

    inlines = [PaymentTransactionInline]
    date_hierarchy = 'created_at'

    def get_amount(self, obj):
        """Formata valor em reais"""
        return f"R$ {obj.amount / 100:.2f}"
    get_amount.short_description = "Valor"

    def get_link_url(self, obj):
        """
        Gera URL do checkout.
        Override este método para customizar o domínio.
        """
        # Busca configuração de domínio
        domain = getattr(settings, 'CHECKOUT_DOMAIN', 'http://localhost:4200')
        
        # obj.key já é string, encode para bytes e depois urlsafe_base64_encode
        key_encoded = urlsafe_base64_encode(obj.key.encode())
        url = f"{domain}/?c={key_encoded}"
        return format_html('<a href="{}" target="_blank">{}</a>', url, url)
    get_link_url.short_description = "URL"

    def get_status_badge(self, obj):
        """Badge visual de status"""
        if obj.used:
            return format_html(
                '<span style="background:green;color:white;padding:3px 8px;border-radius:3px;">USADO</span>'
            )
        if obj.canceled:
            return format_html(
                '<span style="background:red;color:white;padding:3px 8px;border-radius:3px;">CANCELADO</span>'
            )
        if obj.is_valid():
            return format_html(
                '<span style="background:blue;color:white;padding:3px 8px;border-radius:3px;">ATIVO</span>'
            )
        return format_html(
            '<span style="background:orange;color:white;padding:3px 8px;border-radius:3px;">EXPIRADO</span>'
        )
    get_status_badge.short_description = "Status"


# =========================================
# PAYMENT TRANSACTION ADMIN
# =========================================

class PaymentTransactionAdmin(admin.ModelAdmin):
    """Admin para PaymentTransaction"""
    list_display = (
        'id',
        'get_status_badge',
        'payment_method',
        'get_amount',
        'transaction_id',
        'created_at',
        'payment_date'
    )

    list_filter = ('status', 'payment_method', 'gateway_provider', 'created_at')
    search_fields = ('transaction_id',)

    readonly_fields = (
        'created_at', 'payment_date', 'last_update',
        'get_amount', 'payment_response'
    )

    fieldsets = (
        ('Dados', {
            'fields': (
                'status',
                'payment_method',
                'gateway_provider',
                'amount',
                'get_amount',
                'transaction_id'
            )
        }),
        ('Datas', {'fields': ('created_at', 'payment_date', 'last_update')}),
        ('Gateway', {
            'fields': ('payment_response', 'error_message'),
            'classes': ('collapse',)
        }),
    )

    inlines = [PaymentAttemptInline, PaymentWebhookInline]
    date_hierarchy = 'created_at'

    def get_amount(self, obj):
        """Formata valor em reais"""
        return f"R$ {obj.amount / 100:.2f}"
    get_amount.short_description = 'Valor'

    def get_status_badge(self, obj):
        """Badge visual de status com cores"""
        # obj.status já é string interna ('approved', 'pending', etc)
        display_text = StatusHandler.to_display(obj.status)
        print("[DEBUG] get_status_badge called for status:", obj.status)
        print("[DEBUG] Display text:", display_text)
        
        colors = {
            'pending': 'gray',
            'processing': 'blue',
            'approved': 'green',
            'denied': 'red',
            'canceled': 'orange',
            'refunded': 'purple',
            'waiting': 'orange',
        }
        
        return format_html(
            '<span style="background:{};color:white;padding:3px 8px;border-radius:3px;">{}</span>',
            colors.get(obj.status, 'gray'),
            display_text
        )
    get_status_badge.short_description = "Status"


# =========================================
# PAYMENT ATTEMPT ADMIN
# =========================================

class PaymentAttemptAdmin(admin.ModelAdmin):
    """Admin para PaymentAttempt"""
    list_display = ('id', 'transaction', 'status', 'attempted_at', 'error_code')
    list_filter = ('status', 'attempted_at')
    search_fields = ('transaction__transaction_id', 'error_code')

    readonly_fields = ('attempted_at', 'response_data')

    fieldsets = (
        ('Transação', {'fields': ('transaction',)}),
        ('Tentativa', {'fields': ('attempted_at', 'status')}),
        ('Erro', {'fields': ('error_code', 'error_message')}),
        ('Payload', {'fields': ('response_data',), 'classes': ('collapse',)}),
    )

    date_hierarchy = 'attempted_at'


# =========================================
# PAYMENT WEBHOOK ADMIN
# =========================================

class PaymentWebhookAdmin(admin.ModelAdmin):
    """Admin para PaymentWebhook"""
    list_display = ('id', 'transaction', 'event_type', 'received_at', 'get_processed_badge')
    list_filter = ('processed', 'event_type', 'received_at')
    search_fields = ('transaction__transaction_id', 'event_type')

    readonly_fields = ('received_at', 'payload')

    fieldsets = (
        ('Transação', {'fields': ('transaction',)}),
        ('Webhook', {'fields': ('received_at', 'event_type', 'processed')}),
        ('Processamento', {'fields': ('processing_error',)}),
        ('Payload', {'fields': ('payload',), 'classes': ('collapse',)}),
    )

    date_hierarchy = 'received_at'

    def get_processed_badge(self, obj):
        """Badge visual de processamento"""
        if obj.processed:
            return format_html(
                '<span style="background:green;color:white;padding:3px 8px;border-radius:3px;">Processado</span>'
            )
        return format_html(
            '<span style="background:orange;color:white;padding:3px 8px;border-radius:3px;">Pendente</span>'
        )
    get_processed_badge.short_description = "Processado"


# =========================================
# AUTO-REGISTER (quando app está em INSTALLED_APPS)
# =========================================

# Só registra se django_cielo estiver em INSTALLED_APPS
if 'django_cielo' in settings.INSTALLED_APPS:
    try:
        from django_cielo.models import (
            CheckoutLink,
            PaymentTransaction,
            PaymentAttempt,
            PaymentWebhook
        )
        
        # Registrar models
        admin.site.register(CheckoutLink, CheckoutLinkAdmin)
        admin.site.register(PaymentTransaction, PaymentTransactionAdmin)
        admin.site.register(PaymentAttempt, PaymentAttemptAdmin)
        admin.site.register(PaymentWebhook, PaymentWebhookAdmin)
        
    except Exception:
        # Models não disponíveis (talvez usando models customizados)
        pass
