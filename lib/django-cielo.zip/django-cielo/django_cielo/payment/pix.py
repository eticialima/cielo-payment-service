"""
Handler de pagamentos PIX
"""

import uuid
from typing import Dict, Any, Optional, TYPE_CHECKING
from django.utils import timezone
from django_cielo.validators import CustomerValidator, AmountValidator
from django_cielo.utils import (
    generate_merchant_order_id,
    clean_identity,
    get_identity_type,
    log_payment_info,
)

if TYPE_CHECKING:
    from django_cielo.gateway import CieloGateway


class PixPayment:
    """
    Handler para pagamentos PIX (Cielo2)
    
    Exemplo de uso:
        result = gateway.pix.create(
            amount=10000,  # R$ 100,00
            customer={
                'name': 'João Silva',
                'email': 'joao@example.com',
                'cpf': '12345678900'
            },
            expiration_seconds=3600  # 1 hora
        )
    """
    
    def __init__(self, gateway: 'CieloGateway'):
        self.gateway = gateway
    
    def create(
        self,
        amount: int,
        customer: Dict[str, Any],
        merchant_order_id: Optional[str] = None,
        expiration_seconds: int = 3600,
    ) -> Dict[str, Any]:
        """
        Cria um pagamento PIX
        
        Args:
            amount: Valor em centavos (ex: 10000 = R$ 100,00)
            customer: Dados do cliente {'name', 'email', 'cpf'}
            merchant_order_id: ID único do pedido (gerado automaticamente se None)
            expiration_seconds: Tempo de expiração do QR Code (padrão: 3600s = 1h, máximo: 86400s = 24h)
            
        Returns:
            Dict com resultado:
            {
                'status': 'WAITING',
                'payment_id': 'xxx-xxx-xxx',
                'merchant_order_id': 'PIX-xxx',
                'txid': 'xxx',  # Identificador PIX
                'additional_data': {
                    'qr_code': 'codigo_copia_cola',
                    'qr_code_base64': 'imagem_qr_code_base64',
                    'expiration_seconds': 3600,
                    'creation_date': '2025-11-19T10:30:00'
                },
                'raw_response': {...}
            }
            
        Raises:
            CieloValidationError: Se dados forem inválidos
            CieloAPIError: Se houver erro na API
        """
        log_payment_info(
            "Iniciando pagamento PIX",
            {
                "amount": f"R$ {amount/100:.2f}",
                "expiration_seconds": expiration_seconds
            }
        )
        
        # MODO MOCK: Sandbox PIX ainda não disponível
        if self.gateway.settings.pix_mock_mode:
            return self._create_mock_payment(amount, customer, expiration_seconds)
        
        # ETAPA 1: Validar dados
        CustomerValidator.validate_customer_data(customer)
        AmountValidator.validate_amount(amount)
        
        # Limitar tempo de expiração (máximo 24h conforme documentação Cielo2)
        if expiration_seconds > 86400:
            expiration_seconds = 86400
            log_payment_info("Tempo de expiracao ajustado para maximo de 24h")
        
        log_payment_info("Dados validados com sucesso")
        
        # ETAPA 2: Preparar dados
        merchant_order_id = merchant_order_id or generate_merchant_order_id("PIX")
        
        # Preparar CPF/CNPJ
        identity = customer.get('cpf') or customer.get('cnpj') or customer.get('identity', '00000000000')
        clean_id = clean_identity(identity)
        identity_type = get_identity_type(clean_id)
        
        # ETAPA 3: Montar payload (Nova integração Cielo2)
        payload = {
            "MerchantOrderId": merchant_order_id,
            "Customer": {
                "Name": customer['name'],
                "Identity": clean_id,
                "IdentityType": identity_type
            },
            "Payment": {
                "Type": "Pix",
                "Provider": "Cielo2",
                "Amount": int(amount),
                "QrCode": {
                    "Expiration": expiration_seconds
                }
            }
        }
        
        log_payment_info(
            "Payload PIX montado",
            {
                "merchant_order_id": merchant_order_id,
                "identity_type": identity_type
            }
        )
        
        # ETAPA 4: Enviar para Cielo
        response = self.gateway.make_request(
            'POST',
            self.gateway.settings.sales_url,
            data=payload
        )
        
        # ETAPA 5: Processar resposta
        payment_data = response.get('Payment', {})
        payment_id = payment_data.get('PaymentId')
        payment_status = payment_data.get('Status')
        return_code = payment_data.get('ReturnCode', '')
        return_message = payment_data.get('ReturnMessage', '')
        
        # Nova integração Cielo2 - Campos do PIX
        qr_code_string = payment_data.get('QrCodeString')
        qr_code_base64 = payment_data.get('QrCodeBase64Image')
        txid = payment_data.get('SentOrderId')  # Identificador da transação PIX
        
        log_payment_info(
            "Resposta PIX processada",
            {
                "payment_id": payment_id,
                "status": payment_status,
                "return_code": return_code,
                "txid": txid,
                "qr_code_present": bool(qr_code_string)
            }
        )
        
        # VALIDACAO: Verificar se QR Code foi gerado
        if return_code != '0':
            log_payment_info(
                f"Erro ao gerar PIX: [{return_code}] {return_message}",
                debug=True
            )
            
            from django_cielo.exceptions import CieloAPIError
            raise CieloAPIError(
                f"Erro ao gerar PIX: {return_message}",
                code=return_code,
                details=response
            )
        
        if not qr_code_string or not qr_code_base64:
            log_payment_info("QR Code nao foi gerado na resposta", debug=True)
            
            from django_cielo.exceptions import CieloAPIError
            raise CieloAPIError(
                f"QR Code nao foi gerado. {return_message}",
                code=return_code,
                details=response
            )
        
        log_payment_info(
            "QR Code PIX gerado com sucesso",
            {"payment_id": payment_id, "txid": txid}
        )
        
        return {
            'status': 'WAITING',
            'payment_id': payment_id,
            'merchant_order_id': merchant_order_id,
            'txid': txid,
            'additional_data': {
                'qr_code': qr_code_string,
                'qr_code_base64': qr_code_base64,
                'expiration_date_qrcode': None,  # Cielo não retorna data explícita
                'creation_date_qrcode': timezone.now().isoformat(),
                'expiration_seconds': expiration_seconds
            },
            'raw_response': response
        }
    
    def _create_mock_payment(
        self,
        amount: int,
        customer: Dict[str, Any],
        expiration_seconds: int
    ) -> Dict[str, Any]:
        """
        Cria pagamento PIX simulado (modo mock para testes)
        
        Args:
            amount: Valor em centavos
            customer: Dados do cliente
            expiration_seconds: Tempo de expiração
            
        Returns:
            Pagamento simulado
        """
        log_payment_info("MODO MOCK: Gerando PIX simulado", debug=True)
        
        payment_id = f"MOCK-PIX-{uuid.uuid4().hex[:16].upper()}"
        merchant_order_id = generate_merchant_order_id("PIX-MOCK")
        
        # QR Code simulado (formato válido para visualização)
        mock_qr_code = (
            f"00020126580014br.gov.bcb.pix0136{payment_id}"
            f"520400005303986540{amount/100:.2f}5802BR"
            f"5925{customer['name'][:25]}6009SAO PAULO"
            f"62070503***6304"
        )
        
        log_payment_info(
            "PIX MOCK gerado",
            {
                "payment_id": payment_id,
                "merchant_order_id": merchant_order_id
            }
        )
        
        return {
            'status': 'WAITING',
            'payment_id': payment_id,
            'merchant_order_id': merchant_order_id,
            'txid': payment_id,
            'additional_data': {
                'qr_code': mock_qr_code,
                'qr_code_base64': '',  # Frontend pode gerar via API externa
                'expiration_date_qrcode': None,
                'creation_date_qrcode': timezone.now().isoformat(),
                'expiration_seconds': expiration_seconds
            },
            'raw_response': {
                'MOCK': True,
                'PaymentId': payment_id,
                'Status': 12,
                'QrCodeString': mock_qr_code,
                'QrCodeBase64Image': ''
            }
        }
