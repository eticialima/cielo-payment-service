"""
Handler de pagamentos com Cartão de Crédito
"""

from typing import Dict, Any, Optional, TYPE_CHECKING
from django_cielo.enums import CardBrand, ReturnCode
from django_cielo.handlers import StatusHandler
from django_cielo.validators import CardValidator, CustomerValidator, AmountValidator
from django_cielo.utils import (
    generate_merchant_order_id,
    clean_card_number,
    clean_security_code,
    clean_identity,
    format_expiration_date,
    get_identity_type,
    build_address_dict,
    log_payment_info,
)
from django_cielo.exceptions import CieloPaymentDenied

if TYPE_CHECKING:
    from django_cielo.gateway import CieloGateway


class CreditCardPayment:
    """
    Handler para pagamentos com cartão de crédito
    
    Exemplo de uso:
        result = gateway.credit_card.create(
            card_number='4000000000001091',
            cardholder_name='TESTE CIELO',
            expiration_month='12',
            expiration_year='30',
            security_code='123',
            amount=10000,  # R$ 100,00
            customer={
                'name': 'João Silva',
                'email': 'joao@example.com',
                'cpf': '12345678900'
            },
            installments=1,
            capture=True,
            billing_address={...}  # Opcional
        )
    """
    
    def __init__(self, gateway: 'CieloGateway'):
        self.gateway = gateway
    
    def create(
        self,
        card_number: str,
        cardholder_name: str,
        expiration_month: str,
        expiration_year: str,
        security_code: str,
        amount: int,
        customer: Dict[str, Any],
        merchant_order_id: Optional[str] = None,
        installments: int = 1,
        capture: bool = True,
        authenticate: bool = False,
        billing_address: Optional[Dict[str, Any]] = None,
        delivery_address: Optional[Dict[str, Any]] = None,
        session_id: Optional[str] = None,
        client_ip: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Cria um pagamento com cartão de crédito
        
        Args:
            card_number: Número do cartão
            cardholder_name: Nome do titular
            expiration_month: Mês de expiração (01-12)
            expiration_year: Ano de expiração (YY ou YYYY)
            security_code: CVV
            amount: Valor em centavos (ex: 10000 = R$ 100,00)
            customer: Dados do cliente {'name', 'email', 'cpf'}
            merchant_order_id: ID único do pedido (gerado automaticamente se None)
            installments: Número de parcelas (padrão: 1)
            capture: Capturar automaticamente (padrão: True)
            authenticate: Habilitar 3DS (padrão: False)
            billing_address: Endereço de cobrança (opcional)
            delivery_address: Endereço de entrega (opcional)
            session_id: ID da sessão de antifraude (opcional)
            client_ip: IP do cliente (opcional)
            
        Returns:
            Dict com resultado do pagamento:
            {
                'status': 'APPROVED' | 'DENIED' | 'PROCESSING',
                'payment_id': 'xxx-xxx-xxx',
                'merchant_order_id': 'ORDER-xxx',
                'return_code': '00',
                'return_message': 'Successful',
                'cielo_status': 2,
                'raw_response': {...}
            }
            
        Raises:
            CieloValidationError: Se dados forem inválidos
            CieloAPIError: Se houver erro na API
            CieloPaymentDenied: Se pagamento for negado
        """
        log_payment_info(
            "Iniciando pagamento com cartao de credito",
            {
                "amount": f"R$ {amount/100:.2f}",
                "installments": installments,
                "capture": capture
            }
        )
        
        # ETAPA 1: Validar dados
        card_data = {
            'card_number': card_number,
            'cardholder_name': cardholder_name,
            'expiration_month': expiration_month,
            'expiration_year': expiration_year,
            'security_code': security_code,
        }
        CardValidator.validate_card_data(card_data)
        CustomerValidator.validate_customer_data(customer)
        AmountValidator.validate_amount(amount)
        
        log_payment_info("Dados validados com sucesso")
        
        # ETAPA 2: Preparar dados
        clean_number = clean_card_number(card_number)
        card_brand = CardBrand.detect(clean_number)
        merchant_order_id = merchant_order_id or generate_merchant_order_id()
        
        # Preparar CPF/CNPJ
        identity = customer.get('cpf') or customer.get('cnpj') or customer.get('identity', '00000000000')
        clean_id = clean_identity(identity)
        identity_type = get_identity_type(clean_id)
        
        # Preparar endereços
        billing = build_address_dict(**billing_address) if billing_address else build_address_dict()
        delivery = build_address_dict(**delivery_address) if delivery_address else billing
        
        # ETAPA 3: Montar payload
        payload = {
            "MerchantOrderId": merchant_order_id,
            "Customer": {
                "Name": customer['name'],
                "Email": customer['email'],
                "Identity": clean_id,
                "IdentityType": identity_type,
                "Address": delivery,
                "DeliveryAddress": delivery,
                "Billing": billing
            },
            "Payment": {
                "Type": "CreditCard",
                "Amount": amount,
                "Currency": "BRL",
                "Country": "BRA",
                "Installments": installments,
                "Interest": "ByMerchant",
                "Capture": capture,
                "Authenticate": authenticate,
                "SoftDescriptor": self.gateway.settings.soft_descriptor,
                "CreditCard": {
                    "CardNumber": clean_number,
                    "Holder": cardholder_name,
                    "ExpirationDate": format_expiration_date(expiration_month, expiration_year),
                    "SecurityCode": clean_security_code(security_code),
                    "SaveCard": False,
                    "Brand": card_brand,
                    "CardOnFile": {
                        "Usage": "First",
                        "Reason": "Recurring"
                    }
                }
            }
        }
        
        # Adicionar antifraude se session_id fornecido
        if session_id:
            payload["Payment"]["FraudAnalysis"] = {
                "Sequence": "AnalyseFirst",
                "SequenceCriteria": "Always",
                "FingerPrintId": session_id,
                "Provider": "Cybersource",
                "TotalOrderAmount": amount,
                "Browser": {
                    "Email": customer['email'],
                    "IpAddress": client_ip or "127.0.0.1",
                    "CookiesAccepted": False
                }
            }
            log_payment_info(f"Antifraude habilitado com session_id: {session_id}")
        
        log_payment_info(
            "Payload montado",
            {
                "merchant_order_id": merchant_order_id,
                "card_brand": card_brand,
                "identity_type": identity_type
            }
        )
        
        # ETAPA 4: Enviar para Cielo
        response = self.gateway.make_request(
            'POST',
            self.gateway.settings.sales_url,
            data=payload
        )
        
        # ETAPA 5: Processar resposta
        payment_data = response.get('Payment', {})
        payment_id = payment_data.get('PaymentId')
        cielo_status = payment_data.get('Status')
        return_code = payment_data.get('ReturnCode', '')
        return_message = payment_data.get('ReturnMessage', '')
        
        log_payment_info(
            "Resposta da Cielo processada",
            {
                "payment_id": payment_id,
                "cielo_status": cielo_status,
                "return_code": return_code,
                "return_message": return_message
            }
        )
        
        # VALIDACAO CRITICA: Verificar ReturnCode
        if not ReturnCode.is_success(return_code):
            log_payment_info(
                "Pagamento negado via ReturnCode",
                {
                    "return_code": return_code,
                    "return_message": return_message
                }
            )
            
            raise CieloPaymentDenied(
                f"Pagamento negado: {return_message}",
                return_code=return_code,
                return_message=return_message
            )
        
        # Mapear status
        internal_status = StatusHandler.from_cielo(cielo_status)
        
        # Traduzir para status de resposta
        if internal_status == 'approved':
            response_status = 'APPROVED'
        elif internal_status == 'denied':
            response_status = 'DENIED'
        elif internal_status == 'processing':
            response_status = 'PROCESSING'
        else:
            response_status = 'PENDING'
        
        log_payment_info(
            f"Pagamento concluido: {response_status}",
            {"internal_status": internal_status}
        )
        
        return {
            'status': response_status,
            'payment_id': payment_id,
            'merchant_order_id': merchant_order_id,
            'cielo_status': cielo_status,
            'return_code': return_code,
            'return_message': return_message,
            'denial_reason': return_message if response_status == 'DENIED' else '',
            'raw_response': response
        }
