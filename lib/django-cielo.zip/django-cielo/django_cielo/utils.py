"""
Utilitários auxiliares para Django-Cielo
"""

import uuid
import copy
from typing import Dict, Any, Optional
from datetime import datetime


def generate_merchant_order_id(prefix: str = "ORDER") -> str:
    """
    Gera um MerchantOrderId único
    
    Args:
        prefix: Prefixo para o ID
        
    Returns:
        MerchantOrderId único
    """
    return f"{prefix}-{uuid.uuid4().hex[:12].upper()}"


def clean_card_number(card_number: str) -> str:
    """
    Remove espaços e caracteres não numéricos do número do cartão
    
    Args:
        card_number: Número do cartão
        
    Returns:
        Número limpo (apenas dígitos)
    """
    return ''.join(filter(str.isdigit, str(card_number)))


def clean_security_code(security_code: str) -> str:
    """
    Remove caracteres não numéricos do CVV
    
    Args:
        security_code: Código de segurança
        
    Returns:
        CVV limpo (apenas dígitos)
    """
    return ''.join(filter(str.isdigit, str(security_code)))


def clean_identity(identity: str) -> str:
    """
    Remove caracteres não numéricos de CPF/CNPJ
    
    Args:
        identity: CPF ou CNPJ
        
    Returns:
        CPF/CNPJ limpo (apenas dígitos)
    """
    return ''.join(filter(str.isdigit, str(identity)))


def format_expiration_date(month: str, year: str) -> str:
    """
    Formata data de expiração para o padrão Cielo (MM/YYYY)
    
    Args:
        month: Mês (1-12 ou 01-12)
        year: Ano (YY ou YYYY)
        
    Returns:
        Data formatada (MM/YYYY)
    """
    month_int = int(month)
    year_int = int(year)
    
    # Adicionar 2000 se ano tem 2 dígitos
    if year_int < 100:
        year_int += 2000
    
    return f"{month_int:02d}/{year_int}"


def mask_card_number(card_number: str) -> str:
    """
    Mascara número do cartão para logs (mostra primeiros 6 + últimos 4 dígitos)
    
    Args:
        card_number: Número do cartão
        
    Returns:
        Número mascarado (ex: 400000******1091)
    """
    clean_number = clean_card_number(card_number)
    
    if len(clean_number) < 10:
        return "****"
    
    return f"{clean_number[:6]}{'*' * (len(clean_number) - 10)}{clean_number[-4:]}"


def mask_sensitive_data(payload: Dict[str, Any], headers: Dict[str, Any]) -> tuple:
    """
    Mascara dados sensíveis de payload e headers para logs
    
    Args:
        payload: Payload da requisição
        headers: Headers da requisição
        
    Returns:
        Tuple[Dict, Dict]: (payload_mascarado, headers_mascarados)
    """
    safe_payload = copy.deepcopy(payload)
    safe_headers = copy.deepcopy(headers)
    
    # Mascarar dados do cartão no payload
    if "Payment" in safe_payload and "CreditCard" in safe_payload["Payment"]:
        card_data = safe_payload["Payment"]["CreditCard"]
        
        if "CardNumber" in card_data:
            card_data["CardNumber"] = mask_card_number(card_data["CardNumber"])
        
        if "SecurityCode" in card_data:
            card_data["SecurityCode"] = "***"
    
    # Mascarar credenciais nos headers
    if "MerchantId" in safe_headers and len(safe_headers["MerchantId"]) > 20:
        mid = safe_headers["MerchantId"]
        safe_headers["MerchantId"] = f"{mid[:10]}{'*' * 8}{mid[-10:]}"
    
    if "MerchantKey" in safe_headers and len(safe_headers["MerchantKey"]) > 20:
        mkey = safe_headers["MerchantKey"]
        safe_headers["MerchantKey"] = f"{mkey[:10]}{'*' * 8}{mkey[-10:]}"
    
    return safe_payload, safe_headers


def cents_to_currency(amount: int) -> str:
    """
    Converte centavos para string formatada em reais
    
    Args:
        amount: Valor em centavos
        
    Returns:
        Valor formatado (ex: "R$ 100,00")
    """
    return f"R$ {amount / 100:.2f}".replace('.', ',')


def currency_to_cents(amount: float) -> int:
    """
    Converte reais para centavos
    
    Args:
        amount: Valor em reais
        
    Returns:
        Valor em centavos
    """
    return int(amount * 100)


def get_identity_type(identity: str) -> str:
    """
    Detecta se o documento é CPF ou CNPJ baseado no tamanho
    
    Args:
        identity: CPF ou CNPJ (com ou sem formatação)
        
    Returns:
        "CPF" ou "CNPJ"
    """
    clean = clean_identity(identity)
    return "CPF" if len(clean) == 11 else "CNPJ"


def build_address_dict(
    street: str = "",
    number: str = "",
    complement: str = "",
    district: str = "",
    city: str = "",
    state: str = "",
    zip_code: str = "",
    country: str = "BRA"
) -> Dict[str, str]:
    """
    Constrói dicionário de endereço no formato Cielo
    
    Returns:
        Dicionário formatado para a API Cielo
    """
    return {
        "Street": street or "Rua Nao Informada",
        "Number": number or "S/N",
        "Complement": complement or "",
        "District": district or "Centro",
        "City": city or "Cidade",
        "State": state or "SP",
        "Country": country,
        "ZipCode": clean_identity(zip_code) if zip_code else "00000000"
    }


def format_datetime(dt: Optional[datetime] = None) -> str:
    """
    Formata datetime para ISO 8601
    
    Args:
        dt: Datetime a formatar (usa now() se None)
        
    Returns:
        String formatada (ex: "2025-11-19T10:30:00")
    """
    if dt is None:
        dt = datetime.now()
    
    return dt.strftime("%Y-%m-%dT%H:%M:%S")


def parse_cielo_error(response_data: Any) -> Dict[str, str]:
    """
    Parse de erros retornados pela API Cielo
    
    Args:
        response_data: Resposta da API (pode ser dict ou list)
        
    Returns:
        Dict com 'code' e 'message'
    """
    if isinstance(response_data, list) and len(response_data) > 0:
        error = response_data[0]
        return {
            'code': error.get('Code', ''),
            'message': error.get('Message', 'Erro desconhecido')
        }
    
    if isinstance(response_data, dict):
        return {
            'code': response_data.get('Code', ''),
            'message': response_data.get('Message', 'Erro desconhecido')
        }
    
    return {
        'code': 'UNKNOWN',
        'message': 'Erro desconhecido'
    }


def log_payment_info(message: str, details: Dict[str, Any] = None, debug: bool = False):
    """
    Log de informações de pagamento (apenas se debug estiver ativo)
    
    Args:
        message: Mensagem principal
        details: Detalhes adicionais
        debug: Se True, sempre loga. Se False, só loga se CIELO_DEBUG=True
    """
    from django_cielo.settings import default_settings
    
    if debug or default_settings.debug:
        print(f"[Django-Cielo] {message}")
        if details:
            for key, value in details.items():
                print(f"  {key}: {value}")
