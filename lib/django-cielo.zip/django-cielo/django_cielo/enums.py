"""
Enumerações e constantes para a biblioteca Django-Cielo
"""

from enum import Enum


class CardBrand(Enum):
    """Bandeiras de cartão suportadas"""
    VISA = 'Visa'
    MASTER = 'Master'
    AMEX = 'Amex'
    ELO = 'Elo'
    DINERS = 'Diners'
    DISCOVER = 'Discover'
    JCB = 'JCB'
    HIPERCARD = 'Hipercard'
    AURA = 'Aura'
    
    @classmethod
    def detect(cls, card_number: str) -> str:
        """
        Detecta a bandeira do cartão baseado no número
        
        Args:
            card_number: Número do cartão (com ou sem espaços)
            
        Returns:
            Nome da bandeira
        """
        # Remove espaços e caracteres não numéricos
        clean_number = ''.join(filter(str.isdigit, card_number))
        
        # Regras de detecção baseadas nos BINs
        if clean_number.startswith('4'):
            return cls.VISA.value
        elif clean_number.startswith(('51', '52', '53', '54', '55', '22', '23', '24', '25', '26', '27')):
            return cls.MASTER.value
        elif clean_number.startswith(('34', '37')):
            return cls.AMEX.value
        elif clean_number.startswith('6011') or clean_number.startswith('65'):
            return cls.DISCOVER.value
        elif clean_number.startswith('35'):
            return cls.JCB.value
        elif clean_number.startswith(('36', '38')):
            return cls.DINERS.value
        elif clean_number.startswith('606282'):
            return cls.HIPERCARD.value
        elif clean_number.startswith(('636368', '438935', '504175', '451416', '509048', '509067', '509049', '627780')):
            return cls.ELO.value
        elif clean_number.startswith('50'):
            return cls.AURA.value
        else:
            # Fallback para Visa se não detectar
            return cls.VISA.value


class PaymentType(Enum):
    """Tipos de pagamento"""
    CREDIT_CARD = 'CreditCard'
    DEBIT_CARD = 'DebitCard'
    PIX = 'Pix'
    BOLETO = 'Boleto'


class CieloEnvironment(Enum):
    """Ambientes da Cielo"""
    SANDBOX = {
        'sales_url': 'https://apisandbox.cieloecommerce.cielo.com.br',
        'query_url': 'https://apiquerysandbox.cieloecommerce.cielo.com.br/1/sales/'
    }
    PRODUCTION = {
        'sales_url': 'https://api.cieloecommerce.cielo.com.br',
        'query_url': 'https://apiquery.cieloecommerce.cielo.com.br/1/sales/'
    }


class ReturnCode(Enum):
    """Códigos de retorno comuns da Cielo"""
    SUCCESS = '00'
    SUCCESS_ALT_1 = '000'
    SUCCESS_ALT_2 = '0000'
    SUCCESS_RETRY = '4'
    SUCCESS_APPROVED = '6'
    
    # Erros comuns
    INVALID_CREDENTIALS = '002'
    EXPIRED_CARD = '057'
    INSUFFICIENT_FUNDS = '051'
    CARD_PROBLEMS = '070'
    TIMEOUT = '099'
    CRITICAL_ERROR = 'GF'
    
    @classmethod
    def is_success(cls, code: str) -> bool:
        """Verifica se o código indica sucesso"""
        success_codes = ['00', '000', '0000', '4', '6']
        return code in success_codes
