"""
Exceções customizadas para Django-Cielo
"""


class CieloException(Exception):
    """Exceção base para erros da Cielo"""
    
    def __init__(self, message: str, code: str = None, details: dict = None):
        self.message = message
        self.code = code
        self.details = details or {}
        super().__init__(self.message)
    
    def __str__(self):
        if self.code:
            return f"[{self.code}] {self.message}"
        return self.message


class CieloAuthenticationError(CieloException):
    """Erro de autenticação (credenciais inválidas)"""
    pass


class CieloValidationError(CieloException):
    """Erro de validação de dados antes de enviar para a API"""
    pass


class CieloAPIError(CieloException):
    """Erro retornado pela API da Cielo"""
    
    def __init__(self, message: str, code: str = None, status_code: int = None, details: dict = None):
        super().__init__(message, code, details)
        self.status_code = status_code


class CieloPaymentDenied(CieloException):
    """Pagamento negado pela operadora"""
    
    def __init__(self, message: str, return_code: str = None, return_message: str = None):
        super().__init__(message, return_code)
        self.return_message = return_message


class CieloTimeoutError(CieloException):
    """Timeout na comunicação com a API"""
    pass


class PaymentProcessingError(CieloException):
    """Erro ao processar pagamento"""
    pass


class CieloNetworkError(CieloException):
    """Erro de rede/conexão"""
    pass
