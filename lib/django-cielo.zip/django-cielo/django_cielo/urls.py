"""
URLs completas para django-cielo - TUDO via Router (REST API).

Uso no seu projeto:
    # core/urls.py
    urlpatterns = [
        path('payment/', include('django_cielo.urls')),
    ]

Isso cria automaticamente:

    ## CheckoutLink (CRUD + ações):
    GET    /payment/checkoutlink/              - Lista checkouts
    POST   /payment/checkoutlink/              - Cria checkout
    GET    /payment/checkoutlink/{id}/         - Detalhe
    POST   /payment/checkoutlink/{id}/mark_as_canceled/
    GET    /payment/checkoutlink/{id}/get_full_link/
    POST   /payment/checkoutlink/create_payment_link/
    GET    /payment/checkoutlink/{id}/status/
    
    ## Transactions (Readonly + ações):
    GET    /payment/transactions/              - Lista transações
    GET    /payment/transactions/{id}/         - Detalhe
    GET    /payment/transactions/{id}/attempts/
    GET    /payment/transactions/{id}/webhooks/
    
    ## Payment Operations (Ações de pagamento):
    POST   /payment/{checkout_id}/process/   - Processa pagamento
    GET    /payment/{transaction_id}/status/ - Status
    POST   /payment/{transaction_id}/capture/ - Captura
    POST   /payment/{transaction_id}/cancel/  - Cancela
    POST   /payment/webhook/                  - Webhook Cielo

Configure no settings.py:

DJANGO_CIELO_MODELS = {
    'CheckoutLink': 'payment.models.CheckoutLink',
    'PaymentTransaction': 'payment.models.PaymentTransaction',
}

DJANGO_CIELO_VIEWSETS = {
    'CheckoutLink': 'payment.viewsets.CheckoutLinkViewSet',  # opcional
    'PaymentTransaction': 'payment.viewsets.PaymentTransactionViewSet',  # opcional
    'Payment': 'payment.viewsets.PaymentViewSet',  # opcional
}

Se não configurar VIEWSETS, a lib cria automaticamente usando os models.
"""

from django.urls import path, include
from django.conf import settings
from django.utils.module_loading import import_string
from django.core.exceptions import ImproperlyConfigured
from rest_framework.routers import DefaultRouter

app_name = 'django_cielo'


def get_model_class(key):
    """Importa model class configurada em settings.DJANGO_CIELO_MODELS"""
    models_config = getattr(settings, 'DJANGO_CIELO_MODELS', {})
    model_path = models_config.get(key)
    
    if not model_path:
        # Fallback: usa models da própria lib
        from django_cielo import models as lib_models
        return getattr(lib_models, key, None)
    
    try:
        return import_string(model_path)
    except ImportError as e:
        raise ImproperlyConfigured(
            f"Não foi possível importar {model_path}: {e}"
        )


def get_viewset_class(key):
    """Importa ViewSet do projeto ou cria dinamicamente da lib"""
    viewsets_config = getattr(settings, 'DJANGO_CIELO_VIEWSETS', {})
    viewset_path = viewsets_config.get(key)
    
    # Se configurado, usa ViewSet customizado
    if viewset_path:
        try:
            return import_string(viewset_path)
        except ImportError as e:
            raise ImproperlyConfigured(
                f"Não foi possível importar {viewset_path}: {e}"
            )
    
    # Fallback: cria ViewSet dinamicamente
    from django_cielo.viewsets import (
        BaseCheckoutLinkViewSet,
        BasePaymentTransactionViewSet,
        BasePaymentViewSet
    )
    
    if key == 'CheckoutLink':
        CheckoutLinkModel = get_model_class('CheckoutLink')
        if not CheckoutLinkModel:
            return None
        
        class CheckoutLinkViewSet(BaseCheckoutLinkViewSet):
            def get_queryset(self):
                return CheckoutLinkModel.objects.all().order_by('-created_at')
        
        return CheckoutLinkViewSet
    
    elif key == 'PaymentTransaction':
        PaymentTransactionModel = get_model_class('PaymentTransaction')
        if not PaymentTransactionModel:
            return None
        
        class PaymentTransactionViewSet(BasePaymentTransactionViewSet):
            def get_queryset(self):
                return PaymentTransactionModel.objects.all().order_by('-created_at')
        
        return PaymentTransactionViewSet
    
    elif key == 'Payment':
        # ViewSet de operações de pagamento com implementação padrão
        return BasePaymentViewSet
    
    return None


# Router para todos os ViewSets
router = DefaultRouter()

# Registra CheckoutLink ViewSet
try:
    CheckoutLinkViewSet = get_viewset_class('CheckoutLink')
    if CheckoutLinkViewSet:
        router.register(r'checkoutlink', CheckoutLinkViewSet, basename='checkoutlink')
except Exception as e:
    import warnings
    warnings.warn(f"Falha ao registrar CheckoutLinkViewSet: {e}")

# Registra Transactions ViewSet
try:
    PaymentTransactionViewSet = get_viewset_class('PaymentTransaction')
    if PaymentTransactionViewSet:
        router.register(r'transactions', PaymentTransactionViewSet, basename='transactions')
except Exception as e:
    import warnings
    warnings.warn(f"Falha ao registrar PaymentTransactionViewSet: {e}")

# Registra Payment Operations ViewSet
try:
    PaymentViewSet = get_viewset_class('Payment')
    if PaymentViewSet:
        router.register(r'payment', PaymentViewSet, basename='payment')
except Exception as e:
    import warnings
    warnings.warn(f"Falha ao registrar PaymentViewSet: {e}")


# URLs = apenas o router
urlpatterns = router.urls
