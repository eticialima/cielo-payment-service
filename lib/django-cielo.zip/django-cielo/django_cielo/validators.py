"""
Validadores para dados de pagamento
"""

import re
from datetime import datetime
from typing import Tuple, Dict, Any
from django_cielo.exceptions import CieloValidationError
from django_cielo.settings import default_settings


class CardValidator:
    """Validador de dados de cartão de crédito"""
    
    @staticmethod
    def validate_card_number(card_number: str) -> Tuple[bool, str]:
        """
        Valida número do cartão
        
        Returns:
            Tuple[bool, str]: (is_valid, error_message)
        """
        if not card_number:
            return False, "Número do cartão é obrigatório"
        
        # Remove espaços e caracteres não numéricos
        clean_number = ''.join(filter(str.isdigit, card_number))
        
        if len(clean_number) < 12 or len(clean_number) > 19:
            return False, "Número do cartão deve ter entre 12 e 19 dígitos"
        
        # Validação de Luhn (algoritmo de validação de cartão)
        # Pode ser desabilitada com SKIP_CARD_VALIDATION=True (útil para cartões de teste)
        if not default_settings.skip_card_validation:
            if not CardValidator._luhn_check(clean_number):
                return False, "Número do cartão inválido"
        
        return True, ""
    
    @staticmethod
    def _luhn_check(card_number: str) -> bool:
        """Algoritmo de Luhn para validação de cartão"""
        def digits_of(n):
            return [int(d) for d in str(n)]
        
        digits = digits_of(card_number)
        odd_digits = digits[-1::-2]
        even_digits = digits[-2::-2]
        checksum = sum(odd_digits)
        
        for d in even_digits:
            checksum += sum(digits_of(d * 2))
        
        return checksum % 10 == 0
    
    @staticmethod
    def validate_cardholder_name(name: str) -> Tuple[bool, str]:
        """Valida nome do titular"""
        if not name or len(name.strip()) < 3:
            return False, "Nome do titular deve ter no mínimo 3 caracteres"
        
        # Verificar se tem pelo menos um espaço (nome e sobrenome)
        if ' ' not in name.strip():
            return False, "Digite nome e sobrenome do titular"
        
        return True, ""
    
    @staticmethod
    def validate_expiration(month: str, year: str) -> Tuple[bool, str]:
        """Valida data de expiração"""
        if not month or not year:
            return False, "Data de expiração é obrigatória"
        
        try:
            month_int = int(month)
            year_int = int(year)
            
            # Adicionar 2000 se ano tem 2 dígitos
            if year_int < 100:
                year_int += 2000
            
            # Validar mês
            if month_int < 1 or month_int > 12:
                return False, "Mês de expiração inválido"
            
            # Verificar se não está expirado
            now = datetime.now()
            exp_date = datetime(year_int, month_int, 1)
            
            if exp_date < now:
                return False, "Cartão expirado"
            
            return True, ""
            
        except ValueError:
            return False, "Data de expiração inválida"
    
    @staticmethod
    def validate_security_code(cvv: str, card_brand: str = None) -> Tuple[bool, str]:
        """Valida código de segurança (CVV)"""
        if not cvv:
            return False, "Código de segurança (CVV) é obrigatório"
        
        # Remove caracteres não numéricos
        clean_cvv = ''.join(filter(str.isdigit, str(cvv)))
        
        # Amex usa 4 dígitos, outros usam 3
        expected_length = 4 if card_brand == 'Amex' else 3
        
        if len(clean_cvv) != expected_length:
            return False, f"Código de segurança deve ter {expected_length} dígitos"
        
        return True, ""
    
    @staticmethod
    def validate_card_data(card_data: Dict[str, Any]) -> None:
        """
        Valida todos os dados do cartão de uma vez
        
        Raises:
            CieloValidationError: Se alguma validação falhar
        """
        errors = {}
        
        # Validar número do cartão
        is_valid, error = CardValidator.validate_card_number(
            card_data.get('card_number', '')
        )
        if not is_valid:
            errors['card_number'] = error
        
        # Validar nome do titular
        is_valid, error = CardValidator.validate_cardholder_name(
            card_data.get('cardholder_name', '')
        )
        if not is_valid:
            errors['cardholder_name'] = error
        
        # Validar data de expiração
        is_valid, error = CardValidator.validate_expiration(
            card_data.get('expiration_month', ''),
            card_data.get('expiration_year', '')
        )
        if not is_valid:
            errors['expiration'] = error
        
        # Validar CVV
        is_valid, error = CardValidator.validate_security_code(
            card_data.get('security_code', ''),
            card_data.get('brand')
        )
        if not is_valid:
            errors['security_code'] = error
        
        if errors:
            raise CieloValidationError(
                "Dados do cartão inválidos",
                details=errors
            )


class CustomerValidator:
    """Validador de dados do cliente"""
    
    @staticmethod
    def validate_cpf(cpf: str) -> Tuple[bool, str]:
        """Valida CPF"""
        if not cpf:
            return True, ""  # CPF é opcional
        
        # Remove caracteres não numéricos
        clean_cpf = ''.join(filter(str.isdigit, cpf))
        
        if len(clean_cpf) != 11:
            return False, "CPF deve ter 11 dígitos"
        
        # Verificar se todos os dígitos são iguais (CPF inválido)
        if clean_cpf == clean_cpf[0] * 11:
            return False, "CPF inválido"
        
        # Validação do dígito verificador
        # (Algoritmo simplificado - produção deveria usar biblioteca específica)
        return True, ""
    
    @staticmethod
    def validate_cnpj(cnpj: str) -> Tuple[bool, str]:
        """Valida CNPJ"""
        if not cnpj:
            return True, ""  # CNPJ é opcional
        
        # Remove caracteres não numéricos
        clean_cnpj = ''.join(filter(str.isdigit, cnpj))
        
        if len(clean_cnpj) != 14:
            return False, "CNPJ deve ter 14 dígitos"
        
        return True, ""
    
    @staticmethod
    def validate_email(email: str) -> Tuple[bool, str]:
        """Valida email"""
        if not email:
            return False, "Email é obrigatório"
        
        # Regex simples para validação de email
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        if not re.match(pattern, email):
            return False, "Email inválido"
        
        return True, ""
    
    @staticmethod
    def validate_customer_data(customer_data: Dict[str, Any]) -> None:
        """
        Valida dados do cliente
        
        Raises:
            CieloValidationError: Se alguma validação falhar
        """
        errors = {}
        
        # Nome é obrigatório
        if not customer_data.get('name'):
            errors['name'] = "Nome é obrigatório"
        
        # Email é obrigatório
        is_valid, error = CustomerValidator.validate_email(
            customer_data.get('email', '')
        )
        if not is_valid:
            errors['email'] = error
        
        # CPF/CNPJ (opcional, mas validar se fornecido)
        identity = customer_data.get('cpf') or customer_data.get('cnpj') or customer_data.get('identity')
        if identity:
            clean_identity = ''.join(filter(str.isdigit, str(identity)))
            if len(clean_identity) == 11:
                is_valid, error = CustomerValidator.validate_cpf(identity)
                if not is_valid:
                    errors['cpf'] = error
            elif len(clean_identity) == 14:
                is_valid, error = CustomerValidator.validate_cnpj(identity)
                if not is_valid:
                    errors['cnpj'] = error
        
        if errors:
            raise CieloValidationError(
                "Dados do cliente inválidos",
                details=errors
            )


class AmountValidator:
    """Validador de valores monetários"""
    
    @staticmethod
    def validate_amount(amount: int) -> None:
        """
        Valida valor em centavos
        
        Args:
            amount: Valor em centavos (ex: 10000 = R$ 100,00)
            
        Raises:
            CieloValidationError: Se valor for inválido
        """
        if not isinstance(amount, int):
            raise CieloValidationError(
                "Valor deve ser um número inteiro em centavos"
            )
        
        if amount <= 0:
            raise CieloValidationError(
                "Valor deve ser maior que zero"
            )
        
        # Cielo tem limite de transação (geralmente R$ 1.000.000,00)
        if amount > 100000000:  # R$ 1.000.000,00
            raise CieloValidationError(
                "Valor excede o limite máximo permitido"
            )
