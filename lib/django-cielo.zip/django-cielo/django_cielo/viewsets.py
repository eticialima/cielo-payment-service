"""
ViewSets base para django-cielo usando Django REST Framework.

Fornecem CRUD completo + ações customizadas para CheckoutLink e outros models.
Todas as operações são via ViewSets com router, seguindo padrão REST API.
"""

from datetime import timedelta
from rest_framework import viewsets, serializers, status as http_status
from rest_framework.response import Response
from rest_framework.decorators import action
from django.utils import timezone
from django.conf import settings
from django.shortcuts import get_object_or_404
from django.utils.http import urlsafe_base64_encode
from django_cielo.handlers import StatusHandler


class CheckoutLinkSerializer(serializers.ModelSerializer):
    """Serializer ModelSerializer para CheckoutLink"""
    amount_formatted = serializers.SerializerMethodField()
    is_valid = serializers.SerializerMethodField()
    validation_message = serializers.SerializerMethodField()
    
    class Meta:
        from django_cielo.models import CheckoutLink
        model = CheckoutLink
        fields = [
            'id', 'key', 'amount', 'amount_formatted',
            'created_at', 'expires_at', 'used', 'canceled',
            'is_valid', 'validation_message'
        ]
        read_only_fields = ['id', 'key', 'created_at', 'expires_at', 'used', 'canceled']
    
    def get_amount_formatted(self, obj):
        return f"R$ {obj.amount / 100:.2f}"
    
    def get_is_valid(self, obj):
        return obj.is_valid()
    
    def get_validation_message(self, obj):
        return obj.validation_status()


class PaymentTransactionSerializer(serializers.ModelSerializer):
    """Serializer para PaymentTransaction"""
    amount_formatted = serializers.SerializerMethodField()
    status_display = serializers.SerializerMethodField()
    
    class Meta:
        from django_cielo.models import PaymentTransaction
        model = PaymentTransaction
        fields = [
            'id', 'transaction_id', 'cielo_payment_id', 'status', 'status_display',
            'payment_method', 'amount', 'amount_formatted', 'installments',
            'created_at', 'payment_date', 'last_update'
        ]
        read_only_fields = fields  # Todas readonly, transações não são editáveis
    
    def get_amount_formatted(self, obj):
        return f"R$ {obj.amount / 100:.2f}"
    
    def get_status_display(self, obj):
        from django_cielo.handlers import StatusHandler
        return StatusHandler.to_display(StatusHandler.from_cielo(obj.status))


class BaseCheckoutLinkViewSet(viewsets.ModelViewSet):
    """
    ViewSet base para CheckoutLink com CRUD + ações customizadas.
    
    Configure no seu projeto:
    
    # payment/viewsets.py
    from django_cielo.viewsets import BaseCheckoutLinkViewSet
    from django_cielo.models import CheckoutLink
    
    class CheckoutLinkViewSet(BaseCheckoutLinkViewSet):
        queryset = CheckoutLink.objects.all()
    
    # settings.py
    CHECKOUT_LINK_CONFIG = {
        'frontend_url': 'http://localhost:4200',
        'query_param': 'c',  # ?c=key
        'default_expiration_hours': 24,
    }
    """
    
    serializer_class = CheckoutLinkSerializer
    
    def get_queryset(self):
        """Override este método no seu ViewSet"""
        raise NotImplementedError("Defina queryset no seu ViewSet")
    
    def list(self, request, *args, **kwargs):
        """
        Lista checkouts com filtro opcional por key.
        
        GET /checkoutlink/ - Lista todos
        GET /checkoutlink/?key=xxx - Busca por key
        """
        key = request.query_params.get('key')
        
        if key:
            # Busca por key (decodifica se necessário)
            from django.utils.http import urlsafe_base64_decode
            
            try:
                decoded_key = urlsafe_base64_decode(key).decode()
            except Exception:
                decoded_key = key
            
            try:
                checkout = self.get_queryset().get(key=decoded_key)
                serializer = self.get_serializer(checkout)
                return Response(serializer.data)
            except self.get_queryset().model.DoesNotExist:
                return Response(
                    {'error': 'Checkout não encontrado'},
                    status=http_status.HTTP_404_NOT_FOUND
                )
        
        # Lista normal
        return super().list(request, *args, **kwargs)
    
    def get_checkout_config(self):
        """
        Busca configurações do checkout.
        Override para customizar.
        """
        return getattr(settings, 'CHECKOUT_LINK_CONFIG', {
            'frontend_url': 'http://localhost:4200',
            'query_param': 'c',
            'default_expiration_hours': 24,
        })
    
    def build_payment_link(self, checkout):
        """
        Constrói URL do checkout.
        Override para customizar formato da URL.
        """
        config = self.get_checkout_config()
        frontend_url = config.get('frontend_url', 'http://localhost:4200')
        query_param = config.get('query_param', 'c') 
        key_encoded = urlsafe_base64_encode(checkout.key.encode())
        url = f"{frontend_url}/?{query_param}={key_encoded}"

        return url
    
    @action(detail=True, methods=['post'])
    def mark_as_canceled(self, request, pk=None):
        """
        Marca checkout como cancelado.
        
        POST /api/checkoutlink/{id}/mark_as_canceled/
        """
        item = self.get_object()
        
        if item.used:
            return Response(
                {'error': 'Link já foi usado'},
                status=400
            )
        
        if item.canceled:
            return Response(
                {'error': 'Link já está cancelado'},
                status=400
            )
        
        item.canceled = True
        item.save()
        
        return Response({
            'success': True,
            'message': 'Link cancelado com sucesso',
            'data': self.get_serializer(item).data
        })
    
    @action(detail=True, methods=['get'])
    def get_full_link(self, request, pk=None):
        """
        Retorna URL completa do checkout.
        
        GET /api/checkoutlink/{id}/get_full_link/
        """
        item = self.get_object()
        
        return Response({
            'link': self.build_payment_link(item),
            'key': item.key,
            'is_valid': item.is_valid(),
            'validation_message': item.validation_status(),
        })
    
    @action(detail=False, methods=['get'], url_path='by-key/(?P<key>[^/.]+)')
    def get_by_key(self, request, key=None):
        """
        Busca checkout por key (encodada ou não).
        
        GET /checkoutlink/by-key/{key}/
        """
        from django.utils.http import urlsafe_base64_decode
        
        # Tentar decodificar se vier encodada
        try:
            decoded_key = urlsafe_base64_decode(key).decode()
        except Exception:
            # Se falhar, usa a key como está
            decoded_key = key
        
        # Buscar checkout
        try:
            checkout = self.get_queryset().get(key=decoded_key)
        except self.get_queryset().model.DoesNotExist:
            return Response(
                {'error': 'Checkout não encontrado'},
                status=http_status.HTTP_404_NOT_FOUND
            )
        
        # Validar checkout
        if not checkout.is_valid():
            return Response({
                'error': 'Checkout inválido',
                'reason': checkout.validation_status(),
                'key': checkout.key,
                'used': checkout.used,
                'canceled': checkout.canceled,
                'expires_at': checkout.expires_at,
            }, status=http_status.HTTP_400_BAD_REQUEST)
        
        # Retornar dados do checkout
        serializer = self.get_serializer(checkout)
        return Response(serializer.data)
    
    @action(detail=False, methods=['post'])
    def create_payment_link(self, request):
        """
        Cria novo link de pagamento.
        
        POST /api/checkoutlink/create_payment_link/
        
        Body:
        {
            "amount": 10000,  // centavos (R$ 100,00)
            "expiration_hours": 24  // opcional, padrão 24h
        }
        """
        amount = request.data.get('amount')
        
        if not amount:
            return Response(
                {'error': 'amount é obrigatório'},
                status=400
            )
        
        try:
            amount = int(amount)
            if amount <= 0:
                raise ValueError()
        except (ValueError, TypeError):
            return Response(
                {'error': 'amount deve ser um número inteiro positivo (em centavos)'},
                status=400
            )
        
        config = self.get_checkout_config()
        expiration_hours = request.data.get(
            'expiration_hours',
            config.get('default_expiration_hours', 24)
        )
        
        # Criar checkout
        model_class = self.get_queryset().model
        checkout = model_class.objects.create(
            amount=amount,
            expires_at=timezone.now() + timedelta(hours=expiration_hours)
        )
        
        payment_link = self.build_payment_link(checkout)
        
        return Response({
            'success': True,
            'checkout_id': checkout.id,
            'key': checkout.key,
            'payment_link': payment_link,
            'amount': checkout.amount,
            'amount_formatted': f"R$ {checkout.amount / 100:.2f}",
            'created_at': checkout.created_at,
            'expires_at': checkout.expires_at,
            'is_valid': checkout.is_valid(),
        }, status=201)
    
    @action(detail=True, methods=['get'])
    def status(self, request, pk=None):
        """
        Verifica status do checkout.
        
        GET /api/checkoutlink/{id}/status/
        """
        item = self.get_object()
        
        return Response({
            'key': item.key,
            'is_valid': item.is_valid(),
            'validation_status': item.validation_status(),
            'used': item.used,
            'canceled': item.canceled,
            'expires_at': item.expires_at,
            'amount': item.amount,
            'amount_formatted': f"R$ {item.amount / 100:.2f}",
        })


class BasePaymentViewSet(viewsets.ViewSet):
    """
    ViewSet base para operações de pagamento.
    
    Substitui as views de pagamento com ações RESTful:
    - process: POST /payment/{checkout_id}/process/ - Processa pagamento
    - status: GET /payment/{transaction_id}/status/ - Status da transação
    - capture: POST /payment/{transaction_id}/capture/ - Captura pagamento
    - cancel: POST /payment/{transaction_id}/cancel/ - Cancela transação
    - webhook: POST /payment/webhook/ - Webhook Cielo (sem ID)
    
    Implementação padrão incluída! Pode usar direto ou sobrescrever:
    
    # Uso direto (padrão):
    from django_cielo.viewsets import BasePaymentViewSet
    router.register(r'payment', BasePaymentViewSet, basename='payment')
    
    # Ou sobrescrever se precisar customizar:
    class PaymentViewSet(BasePaymentViewSet):
        def get_checkout_object(self, checkout_id):
            # Customizar busca do checkout
            return super().get_checkout_object(checkout_id)
    """
    
    def get_checkout_object(self, checkout_id):
        """
        Busca checkout por ID ou key.
        Override para customizar.
        """
        from django_cielo.models import CheckoutLink
        
        # Tentar por ID numérico
        try:
            return get_object_or_404(CheckoutLink, id=int(checkout_id))
        except (ValueError, TypeError):
            # Se não for numérico, buscar por key
            return get_object_or_404(CheckoutLink, key=checkout_id)
    
    def create_transaction(self, checkout, payment_data):
        """
        Cria transação de pagamento.
        Override para customizar campos adicionais.
        """
        from django_cielo.models import PaymentTransaction
        
        return PaymentTransaction.objects.create(
            content_object=checkout,
            amount=checkout.amount,
            payment_method=payment_data.get('payment_method', 'credit_card'),
            gateway_provider='cielo',
            status='pending',  # Status interno string
        )
    
    def create_attempt(self, transaction, request_data, response_data):
        """
        Registra tentativa de pagamento.
        Override para customizar.
        """
        from django_cielo.models import PaymentAttempt
        import re
        
        # Extrair status da resposta (response já vem normalizado da lib)
        if isinstance(response_data, dict):
            # Se tem raw_response, usar o status Cielo de lá
            if 'raw_response' in response_data:
                cielo_status = response_data.get('cielo_status', 0)
            else:
                # Fallback: tentar pegar do Payment (resposta antiga)
                cielo_status = response_data.get('Payment', {}).get('Status', 0)
            
            error_message = response_data.get('error') or response_data.get('return_message')
            
            # Extrair error_code da mensagem (formato: "[70] Mensagem" ou "70: Mensagem")
            error_code = response_data.get('return_code')
            if not error_code and error_message:
                # Tentar extrair código da mensagem [70], (70), 70:, etc
                match = re.search(r'[\[\(]?(\d+)[\]\)]?[:\s]', error_message)
                if match:
                    error_code = match.group(1)
        else:
            cielo_status = 0
            error_message = str(response_data)
            error_code = None
        
        return PaymentAttempt.objects.create(
            transaction=transaction,
            status=str(cielo_status),
            response_data=response_data if isinstance(response_data, dict) else {},
            error_code=error_code,
            error_message=error_message if error_message and 'successful' not in error_message.lower() else None
        )
    
    @action(detail=False, methods=['post'], url_path='process')
    def process_without_id(self, request):
        """
        Processa pagamento (modo simples - chave no body).
        
        POST /payment/process/
        
        Body: { "chave": "base64_key", "payment_method": "pix", ... }
        """
        # Redirecionar para o método process com pk=None
        return self.process(request, pk=None)
    
    @action(detail=True, methods=['post'])
    def process(self, request, pk=None):
        """
        Processa pagamento do checkout.
        
        POST /payment/{checkout_id}/process/  (novo modo - key/ID na URL)
        POST /payment/process/              (antigo - chave no body - via process_without_id)
        
        Body: dados do cartão/PIX + opcional 'chave' (modo antigo)
        """
        from django_cielo.gateway import CieloGateway
        from django_cielo.exceptions import PaymentProcessingError
        from django.utils.http import urlsafe_base64_decode
        
        print("\n=== PROCESS PAYMENT ===")
        print(f"Request data: {request.data}")
        print(f"PK: {pk}")
        
        # Compatibilidade: aceita 'chave' ou 'checkout_key' no body (modo antigo)
        chave = request.data.get('chave') or request.data.get('checkout_key')
        
        if chave:
            try:
                # Tentar decodificar se estiver encodada
                try:
                    decoded_key = str(urlsafe_base64_decode(chave), 'utf-8')
                    print(f"Chave decodificada: {decoded_key}")
                except:
                    # Se falhar, usar como está (já decodificada)
                    decoded_key = chave
                    print(f"Usando chave sem decode: {decoded_key}")
                checkout = self.get_checkout_object(decoded_key)
                print(f"Checkout encontrado: ID={checkout.id}, amount={checkout.amount}")
            except Exception as e:
                print(f"Erro ao buscar checkout: {e}")
                return Response(
                    {'error': 'Token de checkout inválido', 'detail': str(e)},
                    status=http_status.HTTP_400_BAD_REQUEST
                )
        else:
            # Modo novo: pk na URL
            checkout_id = pk
            checkout = self.get_checkout_object(checkout_id)
        
        # Validações
        if checkout.used:
            return Response(
                {'error': 'Checkout já foi utilizado'},
                status=http_status.HTTP_400_BAD_REQUEST
            )
        
        if checkout.canceled:
            return Response(
                {'error': 'Checkout foi cancelado'},
                status=http_status.HTTP_400_BAD_REQUEST
            )
        
        if not checkout.is_valid():
            return Response(
                {'error': checkout.validation_status()},
                status=http_status.HTTP_400_BAD_REQUEST
            )
        
        # Criar transação
        transaction = self.create_transaction(checkout, request.data)
        print(f"Transação criada: ID={transaction.id}")
        
        try:
            # Processar com Cielo
            gateway = CieloGateway()
            payment_method = request.data.get('payment_method', 'credit_card')
            print(f"Método de pagamento: {payment_method}")
            
            if payment_method == 'pix':
                # Pagamento PIX
                customer = request.data.get('customer', {})
                expiration_seconds = request.data.get('qr_expiration_time', 1800)
                
                response = gateway.pix.create(
                    amount=checkout.amount,
                    customer={
                        'name': customer.get('name', 'Cliente'),
                        'email': customer.get('email'),
                        'cpf': customer.get('cpf') or customer.get('identity', '00000000000')
                    },
                    expiration_seconds=expiration_seconds
                )
                print(f"PIX Response: {response}")
            else:
                # Pagamento com cartão
                card_data = request.data.get('card_data', {})
                customer = request.data.get('customer', {})
                
                # Normalizar nomes dos campos (aceitar variações)
                card_number = card_data.get('card_number') or card_data.get('number')
                holder_name = card_data.get('holder_name') or card_data.get('holder') or card_data.get('cardholder_name')
                exp_month = card_data.get('expiration_month')
                exp_year = card_data.get('expiration_year')
                
                # Se veio expiration_date (MM/YY ou MM/YYYY), separar
                if card_data.get('expiration_date') and '/' in card_data.get('expiration_date'):
                    parts = card_data.get('expiration_date').split('/')
                    exp_month = parts[0]
                    exp_year = parts[1]
                
                print(f"Card data normalized: number={card_number}, holder={holder_name}, exp={exp_month}/{exp_year}")
                
                response = gateway.credit_card.create(
                    card_number=card_number,
                    cardholder_name=holder_name,
                    expiration_month=exp_month,
                    expiration_year=exp_year,
                    security_code=card_data.get('security_code'),
                    amount=checkout.amount,
                    installments=card_data.get('installments', 1),
                    customer={
                        'name': customer.get('name', 'Cliente'),
                        'email': customer.get('email'),
                        'cpf': customer.get('cpf') or customer.get('identity', '00000000000')
                    }
                )
                print(f"Card Response: {response}")
            
            # Registrar tentativa
            self.create_attempt(transaction, request.data, response)
            
            # Atualizar transação com dados da resposta
            if payment_method == 'pix':
                transaction.cielo_payment_id = response.get('payment_id')
                # Converter status Cielo (12) para string interna ('waiting')
                transaction.status = StatusHandler.from_cielo(12)  # PIX sempre começa como WAITING
                transaction.payment_response = response.get('raw_response', {})  # Salvar resposta completa
                transaction.transaction_id = response.get('payment_id')
                transaction.save()
                print(f"Transação PIX salva: status={transaction.status}, payment_response salvo={bool(transaction.payment_response)}")
                
                # PIX: NÃO marcar checkout como usado ainda (só quando pagar)
                # checkout.used será marcado no webhook quando status mudar para pago
                
                # Para PIX, retornar QR code
                return Response({
                    'success': True,
                    'transaction_id': transaction.id,
                    'status': response.get('status'),  # 'WAITING'
                    'payment_id': response.get('payment_id'),
                    'qr_code': response.get('additional_data', {}).get('qr_code'),
                    'qr_code_base64': response.get('additional_data', {}).get('qr_code_base64'),
                    'txid': response.get('txid'),
                    'expiration_seconds': expiration_seconds,
                })
            else:
                # Cartão - salvar todos os dados da resposta
                cielo_status = response.get('cielo_status', 0)
                internal_status = StatusHandler.from_cielo(cielo_status)
                
                transaction.cielo_payment_id = response.get('payment_id')
                transaction.status = internal_status  # Salvar string ('approved', 'denied', etc)
                transaction.payment_response = response.get('raw_response', {})  # Salvar resposta completa
                transaction.transaction_id = response.get('payment_id')  # transaction_id da Cielo
                
                # Se aprovado, marcar data de pagamento
                if response.get('status') == 'APPROVED':
                    transaction.payment_date = timezone.now()
                
                transaction.save()
                print(f"Transação salva: status={transaction.status}, payment_response salvo={bool(transaction.payment_response)}")
                
                # Cartão: marcar checkout como usado SOMENTE se aprovado
                if response.get('status') == 'APPROVED':
                    checkout.used = True
                    checkout.save()
                
                return Response({
                    'success': True,
                    'transaction_id': transaction.id,
                    'status': response.get('status'),  # 'APPROVED', 'DENIED', etc
                    'payment_id': response.get('payment_id'),
                    'merchant_order_id': response.get('merchant_order_id'),
                    'return_code': response.get('return_code'),
                    'return_message': response.get('return_message'),
                })
            
        except Exception as e:
            print(f"Erro ao processar pagamento: {e}")
            import traceback
            traceback.print_exc()
            self.create_attempt(transaction, request.data, {'error': str(e)})
            return Response(
                {'error': str(e)},
                status=http_status.HTTP_400_BAD_REQUEST
            )
    
    @action(detail=True, methods=['get'])
    def status(self, request, pk=None):
        """
        Consulta status da transação.
        
        GET /payment/{transaction_id}/status/
        """
        from django_cielo.gateway import CieloGateway
        from django_cielo.handlers import StatusHandler
        
        transaction_id = pk
        # Implementar get_transaction_object se necessário
        # Para simplificar, assumindo que existe
        from django_cielo.models import PaymentTransaction
        transaction = get_object_or_404(PaymentTransaction, id=transaction_id)
        
        try:
            gateway = CieloGateway()
            response = gateway.query(transaction.cielo_payment_id)
            
            # Atualizar status usando StatusHandler
            cielo_status = response.get('Payment', {}).get('Status', transaction.status)
            internal_status = StatusHandler.from_cielo(cielo_status)
            
            transaction.status = cielo_status
            transaction.save()
            
            return Response({
                'transaction_id': transaction.id,
                'status': internal_status,
                'status_display': StatusHandler.to_display(internal_status),
                'cielo_status': cielo_status,
                'is_final': StatusHandler.is_final(internal_status),
                'is_success': StatusHandler.is_success(internal_status),
                'amount': transaction.amount,
                'cielo_payment_id': transaction.cielo_payment_id,
            })
            
        except Exception as e:
            return Response(
                {'error': str(e)},
                status=http_status.HTTP_400_BAD_REQUEST
            )
    
    @action(detail=True, methods=['post'])
    def capture(self, request, pk=None):
        """
        Captura pagamento pré-autorizado.
        
        POST /payment/{transaction_id}/capture/
        """
        from django_cielo.gateway import CieloGateway
        from django_cielo.models import PaymentTransaction
        from django_cielo.handlers import StatusHandler
        
        transaction_id = pk
        transaction = get_object_or_404(PaymentTransaction, id=transaction_id)
        
        try:
            gateway = CieloGateway()
            response = gateway.capture(transaction.cielo_payment_id)
            
            cielo_status = response.get('Status', transaction.status)
            internal_status = StatusHandler.from_cielo(cielo_status)
            
            transaction.status = cielo_status
            transaction.save()
            
            return Response({
                'success': True,
                'transaction_id': transaction.id,
                'status': internal_status,
                'status_display': StatusHandler.to_display(internal_status),
                'cielo_status': cielo_status,
            })
            
        except Exception as e:
            return Response(
                {'error': str(e)},
                status=http_status.HTTP_400_BAD_REQUEST
            )
    
    @action(detail=True, methods=['post'])
    def cancel(self, request, pk=None):
        """
        Cancela transação.
        
        POST /payment/{transaction_id}/cancel/
        """
        from django_cielo.gateway import CieloGateway
        from django_cielo.models import PaymentTransaction
        from django_cielo.handlers import StatusHandler
        
        transaction_id = pk
        transaction = get_object_or_404(PaymentTransaction, id=transaction_id)
        
        try:
            gateway = CieloGateway()
            response = gateway.cancel(transaction.cielo_payment_id)
            
            cielo_status = response.get('Status', transaction.status)
            internal_status = StatusHandler.from_cielo(cielo_status)
            
            transaction.status = cielo_status
            transaction.save()
            
            return Response({
                'success': True,
                'transaction_id': transaction.id,
                'status': internal_status,
                'status_display': StatusHandler.to_display(internal_status),
                'cielo_status': cielo_status,
            })
            
        except Exception as e:
            return Response(
                {'error': str(e)},
                status=http_status.HTTP_400_BAD_REQUEST
            )
    
    @action(detail=False, methods=['post'], url_path='webhook')
    def webhook(self, request):
        """
        Recebe webhook da Cielo.
        
        POST /payment/webhook/
        
        Usa WebhookHandler para processar automaticamente.
        """
        from django_cielo.models import PaymentTransaction, PaymentWebhook
        from django_cielo.handlers import WebhookHandler
        from django_cielo.gateway import CieloGateway
        
        try:
            # Usar WebhookHandler para processar
            gateway = CieloGateway()
            webhook_handler = WebhookHandler(gateway)
            
            # Validar webhook
            if not webhook_handler.validate_webhook(request.data):
                return Response(
                    {'error': 'Webhook inválido'},
                    status=http_status.HTTP_400_BAD_REQUEST
                )
            
            # Processar webhook (consulta API, atualiza status)
            result = webhook_handler.process(request.data)
            
            if not result['processed']:
                return Response(
                    {'error': result.get('error', 'Erro ao processar webhook')},
                    status=http_status.HTTP_400_BAD_REQUEST
                )
            
            # Buscar transação no banco
            transaction = PaymentTransaction.objects.filter(
                cielo_payment_id=result['payment_id']
            ).first()
            
            if not transaction:
                return Response(
                    {'error': 'Transação não encontrada'},
                    status=http_status.HTTP_404_NOT_FOUND
                )
            
            # Registrar webhook
            webhook = PaymentWebhook.objects.create(
                content_object=transaction,
                event_type=result['change_description'],
                payload=request.data,
                processed=True
            )
            
            # Atualizar status da transação
            transaction.status = result['cielo_status']
            transaction.save()
            
            return Response({
                'success': True,
                'transaction_id': transaction.id,
                'old_status': transaction.status,
                'new_status': result['new_status'],
                'change_type': result['change_description'],
            })
            
        except Exception as e:
            return Response(
                {'error': str(e)},
                status=http_status.HTTP_500_INTERNAL_SERVER_ERROR
            )


class BasePaymentTransactionViewSet(viewsets.ReadOnlyModelViewSet):
    """
    ViewSet base para PaymentTransaction (apenas leitura).
    
    Transações são criadas via PaymentViewSet.process()
    """
    serializer_class = PaymentTransactionSerializer
    
    def get_queryset(self):
        """Override no seu ViewSet"""
        raise NotImplementedError("Defina queryset no seu ViewSet")
    
    @action(detail=True, methods=['get'])
    def attempts(self, request, pk=None):
        """
        Lista tentativas de pagamento da transação.
        
        GET /transactions/{id}/attempts/
        """
        transaction = self.get_object()
        attempts = transaction.attempts.all().order_by('-attempted_at')
        
        return Response({
            'transaction_id': transaction.id,
            'attempts': [
                {
                    'id': a.id,
                    'status': a.status,
                    'attempted_at': a.attempted_at,
                    'error_code': a.error_code,
                    'error_message': a.error_message,
                }
                for a in attempts
            ]
        })
    
    @action(detail=True, methods=['get'])
    def webhooks(self, request, pk=None):
        """
        Lista webhooks recebidos para a transação.
        
        GET /transactions/{id}/webhooks/
        """
        transaction = self.get_object()
        webhooks = transaction.webhooks.all().order_by('-received_at')
        
        return Response({
            'transaction_id': transaction.id,
            'webhooks': [
                {
                    'id': w.id,
                    'event_type': w.event_type,
                    'received_at': w.received_at,
                    'processed': w.processed,
                    'processing_error': w.processing_error,
                }
                for w in webhooks
            ]

        })
