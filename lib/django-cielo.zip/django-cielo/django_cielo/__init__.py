"""
Django-Cielo - Biblioteca de integração com a API Cielo

Exemplo de uso:
    from django_cielo import CieloGateway
    
    gateway = CieloGateway()
    result = gateway.credit_card.create(
        card_number='4000000000001091',
        cardholder_name='TESTE',
        expiration_month='12',
        expiration_year='30',
        security_code='123',
        amount=10000,
        customer={'name': 'João', 'email': 'joao@example.com', 'cpf': '12345678900'}
    )
"""

__version__ = '1.0.0'
__author__ = 'DMC Equipamentos'
__license__ = 'MIT'

from django_cielo.gateway import CieloGateway
from django_cielo.exceptions import (
    CieloException,
    CieloAuthenticationError,
    CieloValidationError,
    CieloAPIError,
    CieloPaymentDenied,
)
from django_cielo.enums import (
    CardBrand,
    PaymentType,
)

__all__ = [
    'CieloGateway',
    'CieloException',
    'CieloAuthenticationError',
    'CieloValidationError',
    'CieloAPIError',
    'CieloPaymentDenied',
    'CardBrand',
    'PaymentType',
]
