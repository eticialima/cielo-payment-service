# Guia Rápido - Django-Cielo

## Instalação Rápida

```bash
cd /home/leticia/DMC/django-cielo
pip install -e .
```

## Configuração Mínima

```python
# settings.py
DJANGO_CIELO = {
    'MERCHANT_ID': 'seu_merchant_id',
    'MERCHANT_KEY': 'sua_merchant_key',
    'SANDBOX': True,
}
```

## Teste Rápido

```python
from django_cielo import CieloGateway

gateway = CieloGateway()

# Teste com cartão sandbox
result = gateway.credit_card.create(
    card_number='4000000000001091',
    cardholder_name='TESTE',
    expiration_month='12',
    expiration_year='30',
    security_code='123',
    amount=10000,
    customer={
        'name': 'Teste',
        'email': 'teste@example.com',
        'cpf': '12345678900'
    }
)

print(result)
```

## Estrutura da Biblioteca

```
django-cielo/
├── django_cielo/
│   ├── __init__.py          # Exports principais
│   ├── gateway.py           # Gateway principal
│   ├── settings.py          # Configurações
│   ├── enums.py             # Enumerações
│   ├── exceptions.py        # Exceções customizadas
│   ├── validators.py        # Validadores
│   ├── utils.py             # Utilitários
│   ├── payment/
│   │   ├── credit_card.py   # Handler cartão
│   │   └── pix.py           # Handler PIX
│   └── handlers/
│       ├── webhook.py       # Handler webhook
│       └── status.py        # Gerenciador status
├── examples/                # Exemplos práticos
├── tests/                   # Testes unitários
├── setup.py                 # Instalação
└── README.md                # Documentação completa
```

## Comandos Úteis

### Instalar em modo desenvolvimento
```bash
pip install -e .
```

### Rodar testes
```bash
pip install pytest pytest-django
pytest tests/
```

### Rodar exemplos
```bash
python examples/exemplo_completo.py
```

## Próximos Passos

1. Configure suas credenciais da Cielo
2. Teste no sandbox primeiro
3. Leia o README.md completo para exemplos avançados
4. Configure webhooks para receber notificações
5. Implemente tratamento de erros adequado

## Suporte

- Documentação: README.md
- Exemplos: examples/
- Issues: GitHub Issues
