# Guia de Pagamento com Cartão de Crédito

Este guia mostra como processar pagamentos com cartão de crédito usando a biblioteca django-cielo.

---

## 📋 Pré-requisitos

1. Biblioteca instalada: `pip install django-cielo`
2. Credenciais da Cielo configuradas no `settings.py`
3. Migrations executadas: `python manage.py migrate`

---

## 🎯 Fluxo Básico

```
Frontend → API → django-cielo → Cielo API → Resposta → Frontend
```

---

## 💳 Exemplo Básico

### 1. Usando o Gateway diretamente

```python
from django_cielo import CieloGateway

gateway = CieloGateway()

result = gateway.credit_card.create(
    card_number='4000000000001091',  # Cartão de teste Sandbox
    cardholder_name='TESTE CIELO',
    expiration_month='12',
    expiration_year='30',
    security_code='123',
    amount=10000,  # R$ 100,00 (em centavos)
    customer={
        'name': 'João Silva',
        'email': 'joao@example.com',
        'cpf': '12345678900'
    }
)

# Verificar resultado
if result['status'] == 'APPROVED':
    print(f"✅ Pagamento aprovado!")
    print(f"ID: {result['payment_id']}")
elif result['status'] == 'DENIED':
    print(f"❌ Pagamento negado: {result['denial_reason']}")
```

---

## 🔄 Usando ViewSets (API REST)

### 1. Configure as URLs

```python
# urls.py
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from django_cielo.viewsets import BasePaymentViewSet

router = DefaultRouter()
router.register(r'payment', BasePaymentViewSet, basename='payment')

urlpatterns = [
    path('api/', include(router.urls)),
]
```

### 2. Crie um CheckoutLink

```python
from django_cielo.models import CheckoutLink
from datetime import timedelta
from django.utils import timezone

checkout = CheckoutLink.objects.create(
    amount=10000,  # R$ 100,00
    expires_at=timezone.now() + timedelta(hours=24)
)

print(f"Chave: {checkout.key}")
```

### 3. Processe o pagamento via API

**Endpoint:** `POST /api/payment/process/`

**Body:**
```json
{
  "chave": "sua_chave_checkout_aqui",
  "payment_method": "credit_card",
  "card_data": {
    "card_number": "4000000000001091",
    "cardholder_name": "TESTE CIELO",
    "expiration_month": "12",
    "expiration_year": "30",
    "security_code": "123"
  },
  "customer": {
    "name": "João Silva",
    "email": "joao@example.com",
    "cpf": "12345678900"
  }
}
```

**Resposta de sucesso:**
```json
{
  "success": true,
  "transaction_id": 123,
  "status": "APPROVED",
  "payment_id": "adf0bca7-1983-487a-b714-f8fa93d5307b",
  "merchant_order_id": "2024112301",
  "return_code": "00",
  "return_message": "Successful"
}
```

**Resposta de erro:**
```json
{
  "success": false,
  "status": "DENIED",
  "return_code": "57",
  "return_message": "Card Expired"
}
```

---

## 🧪 Cartões de Teste (Sandbox)

Use estes cartões para testar diferentes cenários:

| Final do Cartão | Status | Código | Mensagem |
|----------------|--------|--------|----------|
| XXXX.XXXX.XXXX.XXX**0** | Autorizado | 4/6 | Operação realizada com sucesso |
| XXXX.XXXX.XXXX.XXX**1** | Autorizado | 4/6 | Operação realizada com sucesso |
| XXXX.XXXX.XXXX.XXX**2** | Não Autorizado | 05 | Não autorizada |
| XXXX.XXXX.XXXX.XXX**3** | Não Autorizado | 57 | Cartão expirado |
| XXXX.XXXX.XXXX.XXX**5** | Não Autorizado | 78 | Cartão bloqueado |
| XXXX.XXXX.XXXX.XXX**6** | Não Autorizado | 99 | Timeout |
| XXXX.XXXX.XXXX.XXX**7** | Não Autorizado | 77 | Cartão cancelado |
| XXXX.XXXX.XXXX.XXX**8** | Não Autorizado | 70 | Problemas com o cartão |

**Exemplo:** `4000000000001091` = Aprovado ✅

---

## 💰 Parcelamento

```python
result = gateway.credit_card.create(
    card_number='4000000000001091',
    cardholder_name='TESTE',
    expiration_month='12',
    expiration_year='30',
    security_code='123',
    amount=30000,  # R$ 300,00
    installments=3,  # 3x de R$ 100,00
    customer={'name': 'João', 'email': 'joao@test.com', 'cpf': '12345678900'}
)
```

---

## 🏠 Endereço de Cobrança

```python
result = gateway.credit_card.create(
    # ... dados do cartão ...
    billing_address={
        'street': 'Rua Teste',
        'number': '123',
        'complement': 'Apto 45',
        'zip_code': '01310-100',
        'city': 'São Paulo',
        'state': 'SP',
        'country': 'Brasil'
    }
)
```

---

## 📊 Status de Pagamento

| Status Interno | Status Cielo | Descrição |
|---------------|--------------|-----------|
| `pending` | 0 | Aguardando processamento |
| `approved` | 1, 2 | Pagamento aprovado |
| `denied` | 3, 13 | Pagamento negado |
| `canceled` | 10 | Pagamento cancelado |
| `refunded` | 11 | Pagamento reembolsado |

---

## ❌ Tratamento de Erros

```python
from django_cielo.exceptions import (
    CieloException,
    CieloPaymentDenied,
    CieloValidationError
)

try:
    result = gateway.credit_card.create(...)
    
except CieloPaymentDenied as e:
    print(f"Pagamento negado: {e.return_code} - {e.return_message}")
    
except CieloValidationError as e:
    print(f"Dados inválidos: {e}")
    
except CieloException as e:
    print(f"Erro geral: {e}")
```

---

## 🔍 Ver detalhes no Admin

Após processar pagamentos, acesse `/admin/` para ver:

- **01 - Checkout Links** - Links de pagamento criados
- **02 - Transações de Pagamento** - Transações processadas
- **03 - Tentativas de Pagamento** - Histórico de tentativas
- **04 - Webhooks de Pagamento** - Notificações recebidas

---

## 🎓 Próximos Passos

- [Pagamentos PIX](pix.md)
- [Customização da Biblioteca](customizacao.md)
- [Referência da API](api.md)
