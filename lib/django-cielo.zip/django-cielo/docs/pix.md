# Guia de Pagamento PIX

Este guia mostra como gerar pagamentos PIX usando a biblioteca django-cielo.

---

## 📋 Pré-requisitos

1. Biblioteca instalada: `pip install django-cielo`
2. Credenciais da Cielo configuradas no `settings.py`
3. **PIX habilitado** na sua conta Cielo (entre em contato com a Cielo)
4. Migrations executadas: `python manage.py migrate`

---

## 🎯 Fluxo PIX

```
1. Gera QR Code → 2. Cliente escaneia → 3. Paga no banco → 4. Webhook notifica → 5. Status atualizado
```

**Status:** `waiting` → Webhook → `approved`

---

## 💳 Exemplo Básico

### 1. Usando o Gateway diretamente

```python
from django_cielo import CieloGateway

gateway = CieloGateway()

result = gateway.pix.create(
    amount=10000,  # R$ 100,00 (em centavos)
    customer={
        'name': 'João Silva',
        'email': 'joao@example.com',
        'cpf': '12345678900'
    },
    expiration_seconds=3600  # QR Code válido por 1 hora
)

# Resultado
print(f"QR Code: {result['additional_data']['qr_code']}")
print(f"QR Code Base64: {result['additional_data']['qr_code_base64']}")
print(f"Payment ID: {result['payment_id']}")
print(f"Status: {result['status']}")  # 'WAITING'
```

---

## 🔄 Usando ViewSets (API REST)

### 1. Configure as URLs

```python
# urls.py
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from django_cielo.viewsets import BasePaymentViewSet

router = DefaultRouter()
router.register(r'payment', BasePaymentViewSet, basename='payment')

urlpatterns = [
    path('api/', include(router.urls)),
]
```

### 2. Crie um CheckoutLink

```python
from django_cielo.models import CheckoutLink
from datetime import timedelta
from django.utils import timezone

checkout = CheckoutLink.objects.create(
    amount=10000,  # R$ 100,00
    expires_at=timezone.now() + timedelta(hours=24)
)

print(f"Chave: {checkout.key}")
```

### 3. Gere o QR Code via API

**Endpoint:** `POST /api/payment/process/`

**Body:**
```json
{
  "chave": "sua_chave_checkout_aqui",
  "payment_method": "pix",
  "customer": {
    "name": "João Silva",
    "email": "joao@example.com",
    "cpf": "12345678900"
  },
  "qr_expiration_time": 3600
}
```

**Resposta:**
```json
{
  "success": true,
  "transaction_id": 123,
  "status": "WAITING",
  "payment_id": "abc123-...",
  "qr_code": "00020126580014br.gov.bcb.pix...",
  "qr_code_base64": "iVBORw0KGgoAAAANSUhEUgAA...",
  "txid": "E00000000202411230000s123",
  "expiration_seconds": 3600
}
```

---

## 🖼️ Exibir QR Code no Frontend

### HTML/JavaScript

```html
<div id="pix-payment">
  <h3>Escaneie o QR Code para pagar</h3>
  <img id="qr-image" src="" alt="QR Code PIX" />
  <p>Ou copie o código:</p>
  <textarea id="qr-text" readonly></textarea>
  <button onclick="copyQRCode()">Copiar código</button>
  <p id="status">Aguardando pagamento...</p>
</div>

<script>
// Após receber resposta da API
function displayQRCode(response) {
  const qrImage = document.getElementById('qr-image');
  const qrText = document.getElementById('qr-text');
  
  // Exibir QR Code como imagem
  qrImage.src = 'data:image/png;base64,' + response.qr_code_base64;
  
  // Exibir código para cópia
  qrText.value = response.qr_code;
  
  // Iniciar polling para verificar pagamento
  startPolling(response.payment_id);
}

function copyQRCode() {
  const qrText = document.getElementById('qr-text');
  qrText.select();
  document.execCommand('copy');
  alert('Código copiado!');
}

// Verificar status a cada 5 segundos
function startPolling(paymentId) {
  const interval = setInterval(async () => {
    const response = await fetch(`/api/payment/status/${paymentId}/`);
    const data = await response.json();
    
    if (data.status === 'approved') {
      clearInterval(interval);
      document.getElementById('status').textContent = '✅ Pagamento aprovado!';
      // Redirecionar ou mostrar mensagem de sucesso
    }
  }, 5000);
}
</script>
```

---

## 📱 Modo Mock (Testes)

Para testar PIX sem integração real:

```python
# settings.py
DJANGO_CIELO = {
    'MERCHANT_ID': 'xxx',
    'MERCHANT_KEY': 'xxx',
    'SANDBOX': True,
    'PIX_MOCK_MODE': True,  # ✅ Ativa modo simulação
}
```

**No modo mock:**
- QR Code é gerado localmente
- Não faz chamadas reais à Cielo
- Retorna dados fictícios para testes

---

## 🔔 Receber Notificação de Pagamento (Webhook)

### 1. Configure o webhook na Cielo

No painel da Cielo, configure a URL de callback:
```
https://seusite.com/api/payment/webhook/
```

### 2. O webhook já está pronto!

A biblioteca processa automaticamente:

```python
# Webhook recebe notificação da Cielo
# → Atualiza status da transação
# → Marca checkout como usado
# → Registra webhook no banco
```

### 3. Ver webhooks no Admin

Acesse `/admin/` → **04 - Webhooks de Pagamento**

---

## ⏱️ Tempo de Expiração

```python
# QR Code válido por 30 minutos
result = gateway.pix.create(
    amount=10000,
    customer={...},
    expiration_seconds=1800  # 30 * 60
)

# QR Code válido por 24 horas
result = gateway.pix.create(
    amount=10000,
    customer={...},
    expiration_seconds=86400  # 24 * 60 * 60
)
```

**Recomendado:** 30 minutos a 1 hora

---

## 📊 Status PIX

| Status | Descrição |
|--------|-----------|
| `waiting` | Aguardando pagamento (QR Code gerado) |
| `approved` | Pagamento confirmado pelo banco |
| `canceled` | QR Code expirado ou cancelado |

---

## ❌ Tratamento de Erros

```python
from django_cielo.exceptions import CieloException

try:
    result = gateway.pix.create(
        amount=10000,
        customer={'name': 'João', 'email': 'joao@test.com', 'cpf': '12345678900'}
    )
    
except CieloException as e:
    print(f"Erro ao gerar PIX: {e}")
```

---

## 🎯 Fluxo Completo

### 1. **Frontend** - Solicita pagamento PIX
```javascript
const response = await fetch('/api/payment/process/', {
  method: 'POST',
  headers: {'Content-Type': 'application/json'},
  body: JSON.stringify({
    chave: checkout_key,
    payment_method: 'pix',
    customer: {...}
  })
});
```

### 2. **Backend** - Gera QR Code
- Cria transação com `status='waiting'`
- Chama Cielo API
- Retorna QR Code

### 3. **Frontend** - Exibe QR Code
- Mostra imagem ou código para copiar
- Inicia polling para verificar pagamento

### 4. **Cliente** - Escaneia e paga
- Abre app do banco
- Confirma pagamento

### 5. **Cielo** - Envia webhook
- Notifica que pagamento foi aprovado

### 6. **Backend** - Processa webhook
- Atualiza `status='approved'`
- Marca checkout como usado
- Registra webhook

### 7. **Frontend** - Detecta pagamento
- Polling detecta mudança de status
- Redireciona para página de sucesso

---

## 🔍 Ver detalhes no Admin

Acesse `/admin/` para ver:

- **02 - Transações de Pagamento** - Status: "Aguardando Pagamento"
- **04 - Webhooks de Pagamento** - Notificações recebidas

---

## 🎓 Próximos Passos

- [Pagamentos com Cartão](cartao-credito.md)
- [Customização da Biblioteca](customizacao.md)
- [Referência da API](api.md)
