# Guia de Customização

Este guia mostra como estender e customizar a biblioteca django-cielo.

---

## 🎯 Por que customizar?

A biblioteca usa **classes abstratas** que você pode estender para:
- Adicionar campos personalizados
- Customizar lógica de negócio
- Integrar com seus models existentes
- Adicionar validações específicas

---

## 📦 Models Personalizados

### Herdar de BaseCheckoutLink

```python
# payment/models.py
from django_cielo.models import BaseCheckoutLink
from django.db import models

class CheckoutLink(BaseCheckoutLink):
    # Adicionar relacionamento com Order
    order = models.ForeignKey(
        'orders.Order',
        on_delete=models.CASCADE,
        related_name='checkouts'
    )
    
    # Campos customizados
    customer_ip = models.GenericIPAddressField(null=True)
    referrer = models.CharField(max_length=500, blank=True)
    
    class Meta:
        verbose_name = "Link de Checkout"
        verbose_name_plural = "Links de Checkout"
```

### Herdar de BasePaymentTransaction

```python
from django_cielo.models import BasePaymentTransaction

class PaymentTransaction(BasePaymentTransaction):
    # Relacionamento direto (ao invés de GenericForeignKey)
    checkout_link = models.ForeignKey(
        CheckoutLink,
        on_delete=models.PROTECT,
        related_name='transactions'
    )
    
    # Campos adicionais
    customer_ip = models.GenericIPAddressField(null=True)
    risk_score = models.IntegerField(null=True)
    
    class Meta:
        verbose_name = "Transação"
        verbose_name_plural = "Transações"
```

---

## 🔌 ViewSets Personalizados

### Estender BasePaymentViewSet

```python
# payment/views.py
from django_cielo.viewsets import BasePaymentViewSet
from rest_framework.permissions import IsAuthenticated
from rest_framework.decorators import action
from rest_framework.response import Response

class PaymentViewSet(BasePaymentViewSet):
    # Adicionar autenticação
    permission_classes = [IsAuthenticated]
    
    def get_permissions(self):
        # Webhook público, resto privado
        if self.action == 'webhook':
            return []
        return [IsAuthenticated()]
    
    def get_checkout_object(self, checkout_id):
        """Override para usar seu model"""
        from payment.models import CheckoutLink
        return CheckoutLink.objects.get(key=checkout_id)
    
    def create_transaction(self, checkout, payment_data):
        """Override para adicionar campos customizados"""
        from payment.models import PaymentTransaction
        
        return PaymentTransaction.objects.create(
            checkout_link=checkout,
            amount=checkout.amount,
            payment_method=payment_data.get('payment_method', 'credit_card'),
            gateway_provider='cielo',
            status='pending',
            customer_ip=self.request.META.get('REMOTE_ADDR'),  # ✅ Custom
        )
    
    @action(detail=True, methods=['get'])
    def analytics(self, request, pk=None):
        """Endpoint customizado"""
        transaction = self.get_object()
        return Response({
            'transaction_id': transaction.id,
            'amount': transaction.amount,
            'status': transaction.status,
            'created_at': transaction.created_at,
        })
```

### Registrar no router

```python
# urls.py
from rest_framework.routers import DefaultRouter
from payment.views import PaymentViewSet

router = DefaultRouter()
router.register(r'payment', PaymentViewSet, basename='payment')
```

---

## 🎨 Admin Personalizado

### Estender Admin da Biblioteca

```python
# payment/admin.py
from django.contrib import admin
from django_cielo.admin import CheckoutLinkAdmin as BaseCheckoutLinkAdmin
from payment.models import CheckoutLink

# Desregistrar admin padrão (se existir)
# admin.site.unregister(CheckoutLink)

@admin.register(CheckoutLink)
class CheckoutLinkAdmin(BaseCheckoutLinkAdmin):
    # Adicionar campos customizados
    list_display = BaseCheckoutLinkAdmin.list_display + ('order', 'customer_ip')
    
    fieldsets = BaseCheckoutLinkAdmin.fieldsets + (
        ('Informações Extras', {
            'fields': ('order', 'customer_ip', 'referrer')
        }),
    )
    
    def get_queryset(self, request):
        return super().get_queryset(request).select_related('order')
```

---

## 🔧 Gateway Customizado

### Adicionar lógica pré/pós processamento

```python
from django_cielo import CieloGateway

class CustomGateway(CieloGateway):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
    
    def process_payment(self, payment_data):
        """Adiciona validações customizadas"""
        # Validação customizada
        if payment_data['amount'] > 100000:  # R$ 1.000,00
            raise ValueError("Valor acima do limite permitido")
        
        # Chamar método original
        return self.credit_card.create(**payment_data)
```

---

## 🪝 Handlers Customizados

### Estender WebhookHandler

```python
from django_cielo.handlers import WebhookHandler

class CustomWebhookHandler(WebhookHandler):
    def on_payment_approved(self, transaction, webhook_data):
        """Callback quando pagamento é aprovado"""
        super().on_payment_approved(transaction, webhook_data)
        
        # Lógica customizada
        send_confirmation_email(transaction)
        update_inventory(transaction.checkout_link.order)
    
    def on_payment_denied(self, transaction, webhook_data):
        """Callback quando pagamento é negado"""
        super().on_payment_denied(transaction, webhook_data)
        
        # Notificar cliente
        send_payment_failed_email(transaction)
```

---

## 🔐 Autenticação e Permissões

### Proteger endpoints específicos

```python
from rest_framework.permissions import BasePermission

class IsCheckoutOwner(BasePermission):
    """Permite apenas o dono do checkout"""
    def has_object_permission(self, request, view, obj):
        return obj.checkout_link.order.customer == request.user

class PaymentViewSet(BasePaymentViewSet):
    def get_permissions(self):
        if self.action == 'process':
            return []  # Público (validado por chave)
        elif self.action == 'webhook':
            return []  # Público (Cielo chama)
        elif self.action in ['cancel', 'refund']:
            return [IsAuthenticated(), IsCheckoutOwner()]
        return [IsAuthenticated()]
```

---

## 📊 Serializers Customizados

```python
from rest_framework import serializers
from django_cielo.models import PaymentTransaction

class TransactionSerializer(serializers.ModelSerializer):
    order_id = serializers.IntegerField(source='checkout_link.order.id')
    customer_name = serializers.CharField(source='checkout_link.order.customer.name')
    
    class Meta:
        model = PaymentTransaction
        fields = [
            'id', 'status', 'amount', 'payment_method',
            'created_at', 'payment_date', 'order_id', 'customer_name'
        ]

class PaymentViewSet(BasePaymentViewSet):
    serializer_class = TransactionSerializer
```

---

## 🎯 Exemplo Completo

```python
# payment/models.py
from django_cielo.models import BaseCheckoutLink, BasePaymentTransaction

class CheckoutLink(BaseCheckoutLink):
    order = models.ForeignKey('orders.Order', on_delete=models.CASCADE)

class PaymentTransaction(BasePaymentTransaction):
    checkout_link = models.ForeignKey(CheckoutLink, on_delete=models.PROTECT)
    customer_ip = models.GenericIPAddressField(null=True)


# payment/views.py
from django_cielo.viewsets import BasePaymentViewSet
from rest_framework.permissions import IsAuthenticated

class PaymentViewSet(BasePaymentViewSet):
    permission_classes = [IsAuthenticated]
    
    def get_permissions(self):
        if self.action in ['webhook', 'process']:
            return []
        return [IsAuthenticated()]
    
    def create_transaction(self, checkout, payment_data):
        from payment.models import PaymentTransaction
        return PaymentTransaction.objects.create(
            checkout_link=checkout,
            amount=checkout.amount,
            payment_method=payment_data.get('payment_method'),
            status='pending',
            customer_ip=self.request.META.get('REMOTE_ADDR'),
        )


# urls.py
from rest_framework.routers import DefaultRouter
from payment.views import PaymentViewSet

router = DefaultRouter()
router.register(r'payment', PaymentViewSet, basename='payment')


# payment/admin.py
from django.contrib import admin
from django_cielo.admin import (
    CheckoutLinkAdmin as BaseCheckoutLinkAdmin,
    PaymentTransactionAdmin as BaseTransactionAdmin
)

@admin.register(CheckoutLink)
class CheckoutLinkAdmin(BaseCheckoutLinkAdmin):
    list_display = BaseCheckoutLinkAdmin.list_display + ('order',)

@admin.register(PaymentTransaction)
class PaymentTransactionAdmin(BaseTransactionAdmin):
    list_display = BaseTransactionAdmin.list_display + ('customer_ip',)
```

---

## 🎓 Próximos Passos

- [Pagamentos com Cartão](cartao-credito.md)
- [Pagamentos PIX](pix.md)
- [Referência da API](api.md)
